// admin.js — Admin Dashboard (Community Portal mockup style).
//
// Complete rewrite. Same backend API contract as before (session cookie
// + CSRF, fetchJson/postForm/delJson, node approve/token/delete, user +
// group management) but rendering in the mockup
// style: status-bar row, node profile cards (banner, avatar, name+id,
// status dot, caps, load-mini, meta + actions), activity feed (icon +
// text + ts). User/group tables stay tables.

let currentUser = null;
let allPermissions = [];
let groupsData = [];
let editingGroupId = null;

// ===== helpers ==========================================================

function fmt(d) {
  if (!d) return "-";
  const dt = new Date(d);
  return isNaN(dt) ? d : dt.toLocaleString();
}
function escHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escAttr(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function timeAgo(d) {
  if (!d) return "";
  const dt = new Date(d);
  if (isNaN(dt)) return "";
  const s = Math.floor((Date.now() - dt.getTime()) / 1000);
  if (s < 5) return "just now";
  if (s < 60) return s + "s ago";
  const m = Math.floor(s / 60);
  if (m < 60) return m + "m ago";
  const h = Math.floor(m / 60);
  if (h < 24) return h + "h ago";
  const d2 = Math.floor(h / 24);
  return d2 + "d ago";
}
function statusColor(entity) {
  if (entity && entity.status_color) return entity.status_color;
  const s = entity && entity.status;
  if (s === "online" || s === "approved" || s === "idle" || s === "completed") return "ok";
  if (s === "busy" || s === "running" || s === "claimed") return "warn";
  if (s === "pending" || s === "accepted") return "info";
  if (s === "failed" || s === "timed_out" || s === "cancelled" || s === "offline") return "bad";
  return "muted";
}
function statusVar(name) {
  const map = { ok: "var(--ok)", warn: "var(--warn)", bad: "var(--bad)", info: "var(--info)", muted: "var(--muted)" };
  return map[name] || "var(--muted)";
}
function getCsrfToken() {
  const m = document.cookie.match(/(?:^|;\s*)relay_csrf=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}

// ===== API wrappers =====================================================

async function fetchJson(path, opts = {}) {
  const res = await fetch(path, {
    headers: {
      ...opts.headers,
      Accept: "application/json",
      "X-CSRF-Token": getCsrfToken(),
    },
    ...opts,
  });
  if (res.status === 401 || res.status === 403) {
    location.href = "/relay/v2/dashboard/login";
    return new Promise(() => {});
  }
  if (!res.ok) {
    const text = await res.text().catch(() => res.statusText);
    throw new Error(`${res.status} ${text || res.statusText}`);
  }
  return res.json();
}
async function postForm(path, formData) {
  return fetchJson(path, { method: "POST", body: formData });
}
async function delJson(path) {
  return fetchJson(path, { method: "DELETE" });
}

function can(perm) {
  return currentUser && (currentUser.is_master || (currentUser.permissions || []).includes(perm));
}

function adminMsg(text, isError) {
  const el = document.getElementById("adminMsg");
  el.textContent = text;
  el.className = "admin-msg " + (isError ? "error" : "ok");
  setTimeout(() => {
    el.textContent = "";
    el.className = "admin-msg";
  }, 5000);
}

// ===== tabs =============================================================

function showTab(mode) {
  document.getElementById("viewDashboard").classList.toggle("hidden", mode !== "dashboard");
  document.getElementById("viewAdmin").classList.toggle("hidden", mode !== "admin");
  document.getElementById("viewCapabilities").classList.toggle("hidden", mode !== "capabilities");
  document.getElementById("tabDashboard").classList.toggle("active", mode === "dashboard");
  document.getElementById("tabAdmin").classList.toggle("active", mode === "admin");
  document.getElementById("tabCapabilities").classList.toggle("active", mode === "capabilities");
  if (mode === "capabilities") loadCapabilities();
}

// ===== current user =====================================================

async function loadMe() {
  try {
    currentUser = await fetchJson("/relay/v2/dashboard/api/me");
    document.getElementById("tabAdmin").classList.toggle("hidden", !can("users:manage") && !can("groups:manage"));
    document.getElementById("usersSection").classList.toggle("hidden", !can("users:manage"));
    document.getElementById("groupsSection").classList.toggle("hidden", !can("groups:manage"));
    const initials = (currentUser.username || currentUser.user_id || "?")
      .slice(0, 2)
      .toUpperCase();
    document.getElementById("navAvatar").textContent = initials;
  } catch (err) {
    console.error(err);
  }
}

// ===== Token modal ======================================================

function showToken(nodeId, tokenValue) {
  document.getElementById("tokenPath").textContent = `~/.relay/${nodeId}.token`;
  document.getElementById("tokenValue").textContent = tokenValue;
  document.getElementById("tokenOverlay").classList.remove("hidden");
  document.getElementById("tokenBox").classList.remove("hidden");
}
function hideToken() {
  document.getElementById("tokenOverlay").classList.add("hidden");
  document.getElementById("tokenBox").classList.add("hidden");
}
function copyToken() {
  navigator.clipboard
    .writeText(document.getElementById("tokenValue").textContent)
    .then(() => alert("Token copied."));
}

// ===== node actions =====================================================

async function approveNode(nodeId) {
  const role = document.getElementById(`role-${nodeId}`).value;
  const caps = document
    .getElementById(`caps-${nodeId}`)
    .value.split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((name) => ({ name, version: "1.0" }));
  const data = await fetchJson(`/relay/v2/admin/nodes/${encodeURIComponent(nodeId)}/approve`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ role, capabilities: caps }),
  });
  showToken(nodeId, data.token);
  loadAll();
}

async function newToken(nodeId) {
  const data = await fetchJson(`/relay/v2/admin/nodes/${encodeURIComponent(nodeId)}/token`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
  });
  showToken(nodeId, data.token);
  loadAll();
}

async function deleteNode(nodeId, nodeName) {
  if (!confirm(`Delete node ${nodeName} (${nodeId})? This cannot be undone.`)) return;
  try {
    await fetchJson(`/relay/v2/admin/nodes/${encodeURIComponent(nodeId)}`, { method: "DELETE" });
    loadAll();
  } catch (err) {
    alert("Delete failed: " + err.message);
  }
}

function renderAction(n) {
  let actions = "";
  if (n.status === "pending") {
    const caps = (n.capability_names || []).join(", ") || "vault";
    actions = `
      <select id="role-${n.node_id}" class="inline-select">
        <option value="service" selected>service</option>
        <option value="worker">worker</option>
      </select>
      <input id="caps-${n.node_id}" class="inline-input" value="${escAttr(caps)}" />
      <button class="approve-btn" data-node-id="${n.node_id}">Approve</button>
    `;
  } else {
    actions = `<button class="token-btn" data-node-id="${n.node_id}">New Token</button>`;
  }
  if (can("nodes:delete")) {
    actions += ` <button class="btn btn-danger delete-btn" data-node-id="${n.node_id}" data-node-name="${escAttr(n.node_name || "")}">Delete</button>`;
  }
  return actions;
}

// ===== renderers (mockup style) ========================================

function renderSummary(s) {
  const online = s.online_nodes ?? 0;
  const total = s.total_nodes ?? 0;
  const nodesClass = online > 0 ? "ok" : total > 0 ? "bad" : "";
  const stagesClass = (s.active_stages ?? 0) > 0 ? "warn" : "ok";
  const capsCount = (s.total_capabilities ?? 0);
  document.getElementById("summary").innerHTML = `
    <div class="status-item"><div class="num ${nodesClass}">${online}/${total}</div><div class="lbl">nodes online</div></div>
    <div class="status-item"><div class="num">${s.total_tasks ?? 0}</div><div class="lbl">tasks total</div></div>
    <div class="status-item"><div class="num ${stagesClass}">${s.active_stages ?? 0}</div><div class="lbl">active stages</div></div>
    <div class="status-item"><div class="num">${s.total_artifacts ?? 0}</div><div class="lbl">artifacts</div></div>
    <div class="status-item"><div class="num info">${capsCount}</div><div class="lbl">capabilities</div></div>
  `;
}

function nodeAvatarClass(nodeName) {
  const n = (nodeName || "").toLowerCase();
  if (n.includes("cyberfox") || n.includes("felix")) return "cyberfox";
  if (n.includes("mac") || n.includes("m4")) return "mac";
  if (n.includes("ct")) return "ct";
  return "default";
}
function nodeBannerClass(nodeName) {
  const n = (nodeName || "").toLowerCase();
  if (n.includes("mac") || n.includes("m4")) return "warn";
  if (n.includes("ct")) return "ct";
  return "";
}
function nodeAvatarEmoji(nodeName) {
  const n = (nodeName || "").toLowerCase();
  if (n.includes("cyberfox") || n.includes("felix")) return "🦊";
  if (n.includes("mac") || n.includes("m4")) return "💻";
  if (n.includes("ct")) return "🌐";
  return (nodeName || "?").charAt(0).toUpperCase();
}

function renderNodeCard(n) {
  const color = statusColor(n);
  const load = n.load;
  const loadPct = load == null ? null : Math.min(load, 100);
  const loadColor = loadPct == null ? "var(--muted)" : loadPct >= 85 ? "var(--bad)" : loadPct >= 60 ? "var(--warn)" : "var(--ok)";
  const loadText = load == null ? "?" : load + "%";
  // T-210: which load source produced the value (cgroup2/cgroup/loadavg)
  const loadSrc = n.load_source ? ` <span class="load-src" title="load source: ${escAttr(n.load_source)}">${escHtml(n.load_source)}</span>` : "";
  const statusText = n.status == null ? "unknown" : String(n.status);
  const name = n.node_name || n.node_id;
  const caps = (n.capability_names || [])
    .map((c) => `<span class="c">${escHtml(c)}</span>`)
    .join("");
  return `
    <div class="node-card" data-node-id="${escAttr(n.node_id)}" data-node-name="${escAttr(n.node_name || n.node_id)}">
      <div class="banner ${nodeBannerClass(n.node_name)}"></div>
      <div class="body">
        <div class="node-avatar ${nodeAvatarClass(n.node_name)}">${escHtml(nodeAvatarEmoji(n.node_name))}</div>
        <div class="node-name">${escHtml(name)}<span class="node-id">${escHtml(n.node_id)}</span></div>
        <div class="node-status"><span class="dot" style="background:${statusVar(color)}"></span>${escHtml(statusText)} · load ${loadText}${loadSrc}</div>
        <div class="node-caps">${caps || '<span class="node-id">no caps</span>'}</div>
        <div class="load-mini"><div class="f" style="width:${loadPct == null ? 0 : loadPct}%;background:${loadColor}"></div></div>
        <div class="node-meta">
          <span>▲ ${n.task_count ?? 0} tasks</span>
          <span>queue: ${n.queue_depth ?? 0}</span>
          <span>${timeAgo(n.last_seen) || "—"}</span>
        </div>
        <div class="card-actions">${renderAction(n)}</div>
      </div>
    </div>`;
}

function renderTasks(tasks) {
  document.querySelector("#tasks tbody").innerHTML =
    (tasks || [])
      .map(
        (t) => `
      <tr>
        <td class="mono">${escHtml(t.task_id)}</td>
        <td>${escHtml(t.task_name)}</td>
        <td><span class="tag ${statusColor(t)}">${escHtml(t.status)}</span></td>
        <td>${t.priority}</td>
        <td>${fmt(t.created_at)}</td>
      </tr>`
      )
      .join("") || '<tr><td colspan="5" class="empty">No tasks.</td></tr>';
}

function renderStages(stages) {
  document.querySelector("#stages tbody").innerHTML =
    (stages || [])
      .map(
        (st) => `
      <tr>
        <td class="mono">${escHtml(st.stage_id)}</td>
        <td class="mono">${escHtml(st.task_id)}</td>
        <td>${escHtml(st.capability)}</td>
        <td><span class="tag ${statusColor(st)}">${escHtml(st.status)}</span></td>
        <td>${escHtml(st.claimed_by || "-")}</td>
      </tr>`
      )
      .join("") || '<tr><td colspan="5" class="empty">No active stages.</td></tr>';
}

function eventIcon(type) {
  const t = (type || "").toLowerCase();
  if (t.includes("complet") || t.includes("success")) return "✅";
  if (t.includes("fail") || t.includes("error")) return "❌";
  if (t.includes("claim") || t.includes("assign")) return "🔄";
  if (t.includes("status") || t.includes("change")) return "⚡";
  if (t.includes("online") || t.includes("join") || t.includes("register")) return "🔗";
  if (t.includes("artifact") || t.includes("upload")) return "📦";
  if (t.includes("approve")) return "🛡";
  if (t.includes("delete")) return "🗑";
  if (t.includes("user")) return "👤";
  return "•";
}

function renderEvents(events) {
  const list = events || [];
  document.getElementById("events").innerHTML =
    list
      .map((e) => {
        const type = e.type || "event";
        const payload = e.payload || {};
        let body = `<span class="highlight">${escHtml(type)}</span>`;
        try {
          const ps = JSON.stringify(payload);
          if (ps && ps !== "{}") body += ` — <span class="ok">${escHtml(ps)}</span>`;
        } catch (_) {}
        return `
      <div class="activity-item">
        <div class="icon">${eventIcon(type)}</div>
        <div class="ev-body">${body}</div>
        <div class="ts">${fmt(e.timestamp)}</div>
      </div>`;
      })
      .join("") || '<div class="activity-item empty">No events yet.</div>';
}

function renderEndpoints(endpoints) {
  document.querySelector("#endpoints tbody").innerHTML =
    (endpoints || [])
      .map(
        (ep) => `
      <tr>
        <td><span class="tag">${escHtml(ep.method)}</span></td>
        <td class="mono">${escHtml(ep.path)}</td>
        <td>${escHtml(ep.auth)}</td>
        <td>${escHtml(ep.description)}</td>
      </tr>`
      )
      .join("") || '<tr><td colspan="4" class="empty">No endpoints.</td></tr>';
}

// ===== admin (users / groups) ==========================================

async function loadAdmin() {
  if (!can("users:manage") && !can("groups:manage")) return;
  try {
    const reqs = [];
    if (can("users:manage")) reqs.push(fetchJson("/relay/v2/dashboard/api/users"));
    else reqs.push(Promise.resolve({ users: [] }));
    if (can("groups:manage")) {
      reqs.push(fetchJson("/relay/v2/dashboard/api/groups"));
      reqs.push(fetchJson("/relay/v2/dashboard/api/permissions"));
    } else {
      reqs.push(Promise.resolve({ groups: [] }));
      reqs.push(Promise.resolve({ permissions: [] }));
    }
    const [usersData, groupsDataRaw, permsData] = await Promise.all(reqs);
    allPermissions = permsData.permissions || [];
    groupsData = groupsDataRaw.groups || [];
    renderUsers(usersData.users || []);
    renderGroups(groupsData);
    // T-164/T-165: Datei-Übertragung (Schieberegler + Bridge-Ampel).
    loadTransferConfig();
    // T-181: Scheduler claim settings (Claim-TTL + Retries).
    loadSchedulerConfig();
  } catch (err) {
    adminMsg("Admin load failed: " + err.message, true);
    console.error(err);
  }
}

function renderUsers(users) {
  document.querySelector("#users tbody").innerHTML =
    users
      .map(
        (u) => `
    <tr>
      <td>${escHtml(u.username)}</td>
      <td>${escHtml(u.email || "-")}</td>
      <td><input id="groups-${u.user_id}" class="inline-input" value="${escAttr((u.groups || []).join(", "))}" /></td>
      <td><span class="tag ${u.is_active ? "ok" : "muted"}">${u.is_active ? "active" : "inactive"}</span></td>
      <td>${fmt(u.created_at)}</td>
      <td class="admin-actions">
        <button class="token-btn save-groups-btn" data-user-id="${u.user_id}">Save Groups</button>
        <button class="token-btn reset-pw-btn" data-user-id="${u.user_id}">Reset Password</button>
        <button class="approve-btn toggle-active-btn" data-user-id="${u.user_id}" data-active="${!u.is_active}">${u.is_active ? "Deactivate" : "Activate"}</button>
        <button class="btn btn-danger delete-user-btn" data-user-id="${u.user_id}">Delete</button>
      </td>
    </tr>`
      )
      .join("") || '<tr><td colspan="6" class="empty">No users found.</td></tr>';
}

function renderGroups(groups) {
  document.querySelector("#groups tbody").innerHTML =
    groups
      .map(
        (g) => `
    <tr>
      <td>${escHtml(g.group_name)}</td>
      <td>${escHtml(g.description || "-")}</td>
      <td>${(g.permissions || []).map((p) => `<span class="tag">${escHtml(p)}</span>`).join(" ")}</td>
      <td class="admin-actions">
        <button class="token-btn edit-perms-btn" data-group-id="${g.group_id}" data-group-name="${escAttr(g.group_name || "")}">Edit Permissions</button>
      </td>
    </tr>`
      )
      .join("") || '<tr><td colspan="4" class="empty">No groups found.</td></tr>';
}

async function createUser(e) {
  e.preventDefault();
  const form = e.target;
  const data = new FormData(form);
  try {
    await postForm("/relay/v2/dashboard/api/users", data);
    adminMsg("User created.");
    form.reset();
    form.groups.value = "user";
    loadAdmin();
  } catch (err) {
    adminMsg("Create user failed: " + err.message, true);
  }
  return false;
}

async function updateUserGroups(userId) {
  const groups = document.getElementById(`groups-${userId}`).value;
  try {
    await postForm(`/relay/v2/dashboard/api/users/${encodeURIComponent(userId)}/groups`, new URLSearchParams({ groups }));
    adminMsg("Groups updated.");
    loadAdmin();
  } catch (err) {
    adminMsg("Update groups failed: " + err.message, true);
  }
}

async function resetPassword(userId) {
  const password = prompt("Enter new password (min 8 chars):");
  if (!password) return;
  try {
    await postForm(`/relay/v2/dashboard/api/users/${encodeURIComponent(userId)}/password`, new URLSearchParams({ password }));
    adminMsg("Password reset.");
  } catch (err) {
    adminMsg("Password reset failed: " + err.message, true);
  }
}

async function toggleActive(userId, active) {
  try {
    await postForm(`/relay/v2/dashboard/api/users/${encodeURIComponent(userId)}/active`, new URLSearchParams({ active: active ? "true" : "false" }));
    adminMsg(`User ${active ? "activated" : "deactivated"}.`);
    loadAdmin();
  } catch (err) {
    adminMsg("Toggle active failed: " + err.message, true);
  }
}

async function deleteUser(userId) {
  if (!confirm("Delete this user?")) return;
  try {
    await delJson(`/relay/v2/dashboard/api/users/${encodeURIComponent(userId)}`);
    adminMsg("User deleted.");
    loadAdmin();
  } catch (err) {
    adminMsg("Delete user failed: " + err.message, true);
  }
}

// ===== group permissions modal =========================================

function editGroupPerms(groupId, groupName) {
  editingGroupId = groupId;
  document.getElementById("permGroupName").textContent = groupName;
  const group = groupsData.find((g) => g.group_id === groupId) || { permissions: [] };
  const currentPerms = group.permissions || [];
  document.getElementById("permCheckboxes").innerHTML = allPermissions
    .map(
      (p) => `
    <label><input type="checkbox" value="${escAttr(p.permission_name)}" ${currentPerms.includes(p.permission_name) ? "checked" : ""}>
      <span>${escHtml(p.permission_name)}</span>
    </label>`
    )
    .join("");
  document.getElementById("permOverlay").classList.remove("hidden");
  document.getElementById("permBox").classList.remove("hidden");
}

function hidePermModal() {
  document.getElementById("permOverlay").classList.add("hidden");
  document.getElementById("permBox").classList.add("hidden");
  editingGroupId = null;
}

async function saveGroupPerms() {
  if (!editingGroupId) return;
  const checked = Array.from(document.querySelectorAll("#permCheckboxes input:checked")).map((i) => i.value);
  try {
    await postForm(`/relay/v2/dashboard/api/groups/${encodeURIComponent(editingGroupId)}/permissions`, new URLSearchParams({ permissions: checked.join(",") }));
    adminMsg("Group permissions saved.");
    hidePermModal();
    loadAdmin();
  } catch (err) {
    adminMsg("Save permissions failed: " + err.message, true);
  }
}

// ===== Datei-Übertragung (T-164/T-165) =================================

function fmtMB(bytes) {
  if (bytes == null) return "-";
  if (bytes >= 1024 * 1024 * 1024) return (bytes / 1024 / 1024 / 1024).toFixed(1) + " GB";
  return Math.round(bytes / 1024 / 1024) + " MB";
}

async function loadTransferConfig() {
  try {
    const data = await fetchJson("/relay/v2/dashboard/api/transfer-status");
    const inlineMB = Math.round((data.max_inline_bytes || 0) / 1024 / 1024);
    const artifactMB = Math.round((data.max_artifact_bytes || 0) / 1024 / 1024);
    const ttl = data.artifact_ttl_days || 7;

    document.getElementById("sliderInline").value = inlineMB;
    document.getElementById("inlineVal").textContent = inlineMB + " MB";
    document.getElementById("sliderArtifact").value = artifactMB;
    document.getElementById("artifactVal").textContent = fmtMB(data.max_artifact_bytes);
    document.getElementById("sliderTtl").value = ttl;
    document.getElementById("ttlVal").textContent = ttl + " Tage";

    // Bridge-Availability-Ampel
    const ampel = document.getElementById("transferStatus");
    const bridgeOk = data.bridge_available;
    const nodes = (data.bridge_nodes || []).join(", ");
    ampel.innerHTML = `
      <div class="ampel ${bridgeOk ? "ampel-ok" : "ampel-bad"}">
        <span class="ampel-dot"></span>
        <span class="ampel-text">${bridgeOk ? "Bridge verfügbar" : "Bridge nicht verfügbar"}</span>
        ${nodes ? `<span class="ampel-nodes">(${escHtml(nodes)})</span>` : ""}
      </div>
      <div class="ampel-hint">Bridge verfügbar, wenn ein Storage-Node online ist. Ohne Bridge sind Dateien über artifact-max nicht übertragbar.</div>`;
  } catch (err) {
    document.getElementById("transferStatus").innerHTML =
      `<div class="ampel ampel-bad"><span class="ampel-dot"></span><span class="ampel-text">Transfer-Konfig nicht ladbar: ${escHtml(err.message)}</span></div>`;
  }
}

function bindTransferSliders() {
  const inline = document.getElementById("sliderInline");
  const artifact = document.getElementById("sliderArtifact");
  const ttl = document.getElementById("sliderTtl");
  inline.addEventListener("input", () => {
    document.getElementById("inlineVal").textContent = inline.value + " MB";
  });
  artifact.addEventListener("input", () => {
    document.getElementById("artifactVal").textContent = fmtMB(artifact.value * 1024 * 1024);
  });
  ttl.addEventListener("input", () => {
    document.getElementById("ttlVal").textContent = ttl.value + " Tage";
  });
  document.getElementById("btnSaveTransfer").addEventListener("click", saveTransferConfig);
}

async function saveTransferConfig() {
  // F-13: the sliders are MiB — the server wants BYTES. Convert before
  // posting so the saved values round-trip through loadTransferConfig.
  const inline = Number(document.getElementById("sliderInline").value);
  const artifact = Number(document.getElementById("sliderArtifact").value);
  const ttl = Number(document.getElementById("sliderTtl").value);
  const inlineBytes = Math.round(inline * 1024 * 1024);
  const artifactBytes = Math.round(artifact * 1024 * 1024);
  try {
    await postForm("/relay/v2/dashboard/api/transfer-config", new URLSearchParams({
      max_inline_bytes: String(inlineBytes),
      max_artifact_bytes: String(artifactBytes),
      artifact_ttl_days: String(ttl),
    }));
    adminMsg("Transfer-Konfig gespeichert.");
    loadTransferConfig();
  } catch (err) {
    adminMsg("Speichern fehlgeschlagen: " + err.message, true);
  }
}

// ===== Scheduler config (T-181) ========================================

async function loadSchedulerConfig() {
  try {
    const data = await fetchJson("/relay/v2/dashboard/api/scheduler-config");
    document.getElementById("sliderClaimTtl").value = data.claim_ttl_seconds;
    document.getElementById("claimTtlVal").textContent = data.claim_ttl_seconds + " s";
    document.getElementById("sliderMaxRetries").value = data.max_retries;
    document.getElementById("maxRetriesVal").textContent = data.max_retries;
  } catch (err) {
    adminMsg("Scheduler-Konfig konnte nicht geladen werden: " + err.message, true);
  }
}

async function saveSchedulerConfig() {
  const ttl = document.getElementById("sliderClaimTtl").value;
  const retries = document.getElementById("sliderMaxRetries").value;
  try {
    await postForm("/relay/v2/dashboard/api/scheduler-config", new URLSearchParams({
      claim_ttl_seconds: ttl,
      max_retries: retries,
    }));
    adminMsg("Scheduler-Konfig gespeichert (wirkt sofort, ohne Neustart).");
    loadSchedulerConfig();
  } catch (err) {
    adminMsg("Speichern fehlgeschlagen: " + err.message, true);
  }
}

function bindSchedulerSliders() {
  const ttlSlider = document.getElementById("sliderClaimTtl");
  const retriesSlider = document.getElementById("sliderMaxRetries");
  ttlSlider.addEventListener("input", () => {
    document.getElementById("claimTtlVal").textContent = ttlSlider.value + " s";
  });
  retriesSlider.addEventListener("input", () => {
    document.getElementById("maxRetriesVal").textContent = retriesSlider.value;
  });
  document.getElementById("btnSaveScheduler").addEventListener("click", saveSchedulerConfig);
}

// ===== Capabilities tab =================================================

function renderCapabilityCard(c) {
  const nodeCount = (c.nodes || []).length;
  return `
    <div class="cap-card">
      <div class="cap-name">${escHtml(c.name)}</div>
      <p class="cap-desc">${escHtml(c.description || "No description")}</p>
      <div class="node-caps">
        <span class="tag info">${escHtml(c.type || "unknown")}</span>
        <span class="tag muted">${nodeCount} node(s)</span>
      </div>
    </div>`;
}

async function loadCapabilities() {
  try {
    const capsReq = await fetchJson("/relay/v2/dashboard/api/capabilities");
    const caps = capsReq.capabilities || [];
    const container = document.getElementById("capabilityCards");
    if (!caps.length) {
      container.innerHTML = '<p class="empty">No capabilities advertised.</p>';
      return;
    }
    container.innerHTML = caps.map(renderCapabilityCard).join("");
  } catch (err) {
    console.error("loadCapabilities failed:", err);
  }
}

function hideNodePageModal() {
  const frame = document.getElementById("nodePageFrame");
  frame.src = "about:blank";
  document.getElementById("nodePageOverlay").classList.add("hidden");
  document.getElementById("nodePageBox").classList.add("hidden");
}

// ===== main load =======================================================

async function loadAll() {
  const btn = document.getElementById("btnRefresh");
  btn.disabled = true;
  document.getElementById("status").textContent = "loading...";
  try {
    const [overview, endpoints, events] = await Promise.all([
      fetchJson("/relay/v2/dashboard/api/overview"),
      fetchJson("/relay/v2/dashboard/api/endpoints"),
      fetchJson("/relay/v2/dashboard/api/events/recent?limit=50"),
    ]);

    const userNodes = (overview.nodes || []).filter((n) => n.node_id !== "__dashboard_admin__");

    renderSummary(overview.summary || {});
    document.getElementById("nodeCards").innerHTML =
      userNodes.map(renderNodeCard).join("") || '<p class="empty">No nodes registered.</p>';
    renderTasks(overview.tasks);
    renderStages(overview.active_stages);
    renderEvents(events.events);
    renderEndpoints(endpoints.endpoints);

    document.getElementById("status").textContent = "updated " + fmt(overview.generated_at);
  } catch (err) {
    document.getElementById("status").innerHTML = `<span class="error">error: ${escHtml(err.message)}</span>`;
    console.error(err);
  } finally {
    btn.disabled = false;
  }
}

// ===== bootstrap =======================================================

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".tab").forEach((el) => {
    el.addEventListener("click", () => showTab(el.dataset.tab));
  });

  document.getElementById("btnRefresh")?.addEventListener("click", loadAll);

  document.querySelector(".copy-token-btn")?.addEventListener("click", copyToken);
  document.querySelector(".close-token-btn")?.addEventListener("click", hideToken);
  document.getElementById("tokenOverlay")?.addEventListener("click", hideToken);

  document.querySelector(".save-perms-btn")?.addEventListener("click", saveGroupPerms);
  document.querySelector(".cancel-perms-btn")?.addEventListener("click", hidePermModal);
  document.getElementById("permOverlay")?.addEventListener("click", hidePermModal);

  document.getElementById("createUserForm")?.addEventListener("submit", createUser);

  // Node actions (approve / token / delete) inside node cards.
  document.addEventListener("click", (e) => {
    // Click on a node card → open profile page in overlay
    const card = e.target.closest(".node-card");
    if (card && !e.target.closest("button, .approve-btn, .token-btn, .delete-btn")) {
      const name = card.dataset.nodeName;
      if (name) {
        const frame = document.getElementById("nodePageFrame");
        frame.src = "/relay/v2/dashboard/node/" + encodeURIComponent(name);
        document.getElementById("nodePageTitle").textContent = name;
        document.getElementById("nodePageOverlay").classList.remove("hidden");
        document.getElementById("nodePageBox").classList.remove("hidden");
        return;
      }
    }
    const approveBtn = e.target.closest(".approve-btn");
    if (approveBtn && approveBtn.dataset.nodeId) {
      approveNode(approveBtn.dataset.nodeId);
      return;
    }
    const tokenBtn = e.target.closest(".token-btn");
    if (tokenBtn && tokenBtn.dataset.nodeId) {
      newToken(tokenBtn.dataset.nodeId);
      return;
    }
    const delBtn = e.target.closest(".delete-btn");
    if (delBtn) {
      deleteNode(delBtn.dataset.nodeId, delBtn.dataset.nodeName);
      return;
    }
  });

  // User actions inside the users table.
  document.addEventListener("click", (e) => {
    const groupsBtn = e.target.closest(".save-groups-btn");
    if (groupsBtn) {
      updateUserGroups(groupsBtn.dataset.userId);
      return;
    }
    const resetBtn = e.target.closest(".reset-pw-btn");
    if (resetBtn) {
      resetPassword(resetBtn.dataset.userId);
      return;
    }
    const toggleBtn = e.target.closest(".toggle-active-btn");
    if (toggleBtn) {
      toggleActive(toggleBtn.dataset.userId, toggleBtn.dataset.active === "true");
      return;
    }
    const delUserBtn = e.target.closest(".delete-user-btn");
    if (delUserBtn) {
      deleteUser(delUserBtn.dataset.userId);
      return;
    }
  });

  // Group permissions button.
  document.addEventListener("click", (e) => {
    const editBtn = e.target.closest(".edit-perms-btn");
    if (editBtn) {
      editGroupPerms(editBtn.dataset.groupId, editBtn.dataset.groupName);
      return;
    }
  });

  document.getElementById("nodePageOverlay")?.addEventListener("click", hideNodePageModal);
  document.querySelector(".close-node-page-btn")?.addEventListener("click", hideNodePageModal);

  // T-164/T-165: Datei-Übertragung — Schieberegler + Bridge-Ampel.
  bindTransferSliders();
  bindSchedulerSliders();

  loadMe().then(() => {
    loadAll();
    loadAdmin();
  });
  setInterval(() => {
    loadAll();
    if (!document.getElementById("viewAdmin").classList.contains("hidden")) loadAdmin();
  }, 10000);
});