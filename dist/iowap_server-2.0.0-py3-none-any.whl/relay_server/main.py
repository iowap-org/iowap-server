"""IOWAP — Main Entry Point"""

import argparse
import asyncio
import logging
import sys
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse, RedirectResponse
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

# uvloop: faster asyncio event loop (Linux/macOS). Falls back to stdlib on Windows.
try:
    import uvloop  # noqa: F811

    uvloop.install()
except ImportError:
    pass

from relay_server import __version__
from relay_server.api.v2 import router as v2_router
from relay_server.config import settings
from relay_server.core.db import apply_settings_overrides, init_db, q
from relay_server.core.events import event_bus
from relay_server.core import metrics as _metrics
from relay_server.core.logging_setup import JsonFormatter
from relay_server.core.maintenance import MaintenanceScheduler, maintenance_scheduler
from relay_server.core.session import unsign_user_cookie
from relay_server.core.users import list_users
from relay_server.core.zeroconf import RelayZeroconf

_SECURITY_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "connect-src 'self'; "
        "img-src 'self' data:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    ),
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
}

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper()),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

# T-109: structured JSON logs with per-request trace_id. The basicConfig
# above is kept as a fallback; replace the root handler with a JSON one.
_handler = logging.StreamHandler()
_handler.setFormatter(JsonFormatter())
_root_logger = logging.getLogger()
_root_logger.handlers = [_handler]
_root_logger.setLevel(getattr(logging, settings.log_level.upper()))
logger = logging.getLogger("relay")

# Shared IP-based rate limiter used by auth and dashboard routers.
limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / Shutdown hook."""
    logger.info("Initializing database at %s", settings.db_path)
    init_db()
    # T-164/T-165: apply DB-persisted config overrides (transfer ladder +
    # artifact TTL) on top of the YAML/env defaults.
    apply_settings_overrides()
    settings.artifacts_dir.mkdir(parents=True, exist_ok=True)
    logger.info("IOWAP v%s starting on %s:%s", __version__, settings.host, settings.port)

    # Enforce a persistent session secret for cookie signing.
    if not settings.session_secret or len(settings.session_secret) < 32:
        raise RuntimeError(
            "RELAY_SESSION_SECRET must be set to a secret of at least 32 characters. "
            "Configure it via RELAY_SESSION_SECRET or session_secret in config.yaml."
        )

    # T-050: single MaintenanceScheduler bundles every periodic watchdog.
    # T-181: module-level singleton so dashboard edits can re-register
    # watchdogs with fresh intervals (see apply_settings_overrides).
    maintenance_scheduler.register_defaults()
    maintenance_task = asyncio.create_task(_maintenance_loop(maintenance_scheduler))

    # T-187/T-208: names (hostname + service name) come from settings inside
    # RelayZeroconf — IOWAP defaults, both configurable. The hard TLS gate
    # lives in start() itself, so a mismatched config can never advertise.
    mdns = RelayZeroconf(port=settings.port)
    if settings.enable_mdns:
        if settings.tls_certfile:
            # T-111: TLS active = Internet/Community-Relay mode. mDNS is a
            # LAN discovery mechanism and should not advertise on the public
            # internet, so it is suppressed when TLS is on.
            logger.info("mDNS disabled because TLS is active (Internet mode)")
        else:
            # Start mDNS in the background so it cannot block server startup.
            asyncio.get_running_loop().run_in_executor(None, mdns.start)

    try:
        yield
    finally:
        mdns.stop()  # no-op when mDNS was never started
        maintenance_task.cancel()
        try:
            await asyncio.wait_for(maintenance_task, timeout=10)
        except asyncio.CancelledError:
            pass
        except asyncio.TimeoutError:
            logger.warning("Maintenance task did not stop within 10s, continuing shutdown")
        # One final sweep on graceful shutdown (best effort, never raises).
        try:
            final = await asyncio.wait_for(
                asyncio.to_thread(maintenance_scheduler.run_all), timeout=10
            )
            for name, result in final.items():
                if result and not (len(result) == 1 and result.get("error")):
                    logger.info("Maintenance [%s] shutdown run: %s", name, result)
        except Exception as e:  # noqa: BLE001
            logger.warning("Final maintenance sweep failed: %s", e)
        logger.info("Shutting down IOWAP")


async def _maintenance_loop(maintenance: MaintenanceScheduler):
    """Single asyncio task driving all periodic maintenance work (T-050).

    Runs every ``settings.maintenance_interval_seconds``; the scheduler
    itself decides per-task whether its individual interval is due.
    """
    while True:
        try:
            # F-20: evaluate the sweep's real outcome instead of assuming
            # success — run_due never raises; per-task exceptions come back
            # as {"error": ...} result dicts and must degrade /ready.
            from relay_server.core.metrics import evaluate_maintenance_results

            results = await asyncio.to_thread(maintenance.run_due)
            _metrics.mark_maintenance_run(ok=evaluate_maintenance_results(results))
            for name, result in results.items():
                # Only log when the task actually did something. Empty
                # dicts / all-zero counters are treated as no-ops.
                if result and not _is_noop_result(result):
                    logger.info("Maintenance [%s]: %s", name, result)
        except Exception as e:  # noqa: BLE001 — loop must never die
            _metrics.mark_maintenance_run(ok=False)
            logger.exception("Maintenance loop error: %s", e)
        await asyncio.sleep(settings.maintenance_interval_seconds)


def _is_noop_result(result: dict) -> bool:
    """True when a maintenance result indicates nothing was changed."""
    if not isinstance(result, dict):
        return False
    if result.get("error"):
        return False
    for v in result.values():
        if isinstance(v, (list, tuple, dict)) and len(v) > 0:
            return False
        if isinstance(v, int) and v > 0:
            return False
        if isinstance(v, bool) and v:
            return False
    return True


def _rate_limit_handler(request: Request, exc: RateLimitExceeded):
    """Convert slowapi's default error into JSON for API consumers."""
    return JSONResponse(
        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        content={"detail": "Rate limit exceeded"},
        headers={"Retry-After": exc.headers.get("Retry-After", "60")} if exc.headers else {},
    )


app = FastAPI(
    title="IOWAP",
    version=__version__,
    lifespan=lifespan,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)


# Node-declared pages and profiles are served via Dynamic Routes under
# /relay/v2/dashboard/api/node-routes/ and node profile pages under
# /relay/v2/dashboard/node/. The iframe embeds operator-provided HTML,
# so inline scripts/styles are permitted and frame-ancestors is relaxed
# to 'self' so the dashboard can embed them.
_NODE_ROUTES_PREFIX = "/relay/v2/dashboard/api/node-routes/"
_NODE_PROFILE_PREFIX = "/relay/v2/dashboard/node/"
_NODE_ROUTES_CSP = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data:; "
    "connect-src 'self'; "
    "frame-ancestors 'self'; "
    "base-uri 'self'; "
    "form-action 'self'"
)


@app.middleware("http")
async def _trace_id_middleware(request, call_next):
    """Set a trace_id (contextvars) per request for structured logs (T-109).

    FastAPI runs middlewares in reverse decoration order;
    since this middleware is declared first, it runs as the outermost
    layer, and the trace_id is visible in all subsequent middlewares and
    endpoint log calls.
    """
    from relay_server.core.logging_setup import current_trace_id, new_trace_id, set_trace_id

    set_trace_id(new_trace_id())
    response = await call_next(request)
    response.headers["X-Relay-Trace-Id"] = current_trace_id()
    return response


@app.middleware("http")
async def _security_headers_middleware(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith(_NODE_ROUTES_PREFIX):
        response.headers["Content-Security-Policy"] = _NODE_ROUTES_CSP
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
    elif request.url.path.startswith(_NODE_PROFILE_PREFIX):
        response.headers["Content-Security-Policy"] = _NODE_ROUTES_CSP
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
    else:
        for name, value in _SECURITY_HEADERS.items():
            response.headers[name] = value
        # HSTS only makes sense when the relay terminates TLS itself; in the
        # Homelab default (plain HTTP over Tailscale/WireGuard) it would
        # break the connection. Emit it only when TLS is active (S4, Claude
        # review 2026-08-11).
        if settings.tls_certfile:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


@app.middleware("http")
async def _force_password_change_middleware(request, call_next):
    """Block normal dashboard use until a user with force_password_change changes their password."""
    path = request.url.path
    allowed_paths = {
        "/relay/v2/dashboard/login",
        "/relay/v2/dashboard/change-password",
        "/relay/v2/dashboard/bootstrap",
        "/relay/v2/dashboard/api/bootstrap",
        "/relay/v2/dashboard/api/me/password",
        "/relay/v2/dashboard/logout",
    }
    allowed_prefixes = ("/relay/v2/dashboard/static/",)
    if path not in allowed_paths and not any(path.startswith(p) for p in allowed_prefixes):
        relay_user = request.cookies.get("relay_user")
        if relay_user:
            from relay_server.api.v2.security import unsign_user_cookie, list_users

            user_data = unsign_user_cookie(relay_user)
            if user_data and user_data.get("user_id") and user_data.get("user_id") != "__master__":
                for user in list_users():
                    if user["user_id"] == user_data["user_id"] and user.get("force_password_change"):
                        return JSONResponse(
                            status_code=status.HTTP_403_FORBIDDEN,
                            content={"detail": "Password change required"},
                        )
    response = await call_next(request)
    return response


@app.middleware("http")
async def _metrics_middleware(request, call_next):
    """Count 401/403/429 responses globally as auth-failure counters (T-109)."""
    response = await call_next(request)
    if response.status_code in (401, 403, 429):
        _metrics.inc("relay_auth_failures_total", {"endpoint": request.url.path})
    return response


app.include_router(v2_router, prefix="/relay/v2")


@app.get("/dashboard", include_in_schema=False)
async def dashboard_root_redirect(request: Request):
    """Redirect shorthand /dashboard to login, change-password or dashboard."""
    relay_user = request.cookies.get("relay_user")
    if relay_user:
        try:
            user_data = unsign_user_cookie(relay_user)
            user_id = user_data.get("user_id")
            for user in list_users():
                if user["user_id"] == user_id and user["is_active"]:
                    if user.get("force_password_change"):
                        return RedirectResponse(url="/relay/v2/dashboard/change-password", status_code=303)
                    return RedirectResponse(url="/relay/v2/dashboard/", status_code=303)
        except Exception:
            pass
    return RedirectResponse(url="/relay/v2/dashboard/login", status_code=303)


@app.get("/dashboard/login", include_in_schema=False)
async def dashboard_login_redirect(request: Request):
    """Redirect shorthand /dashboard/login to the canonical login page."""
    return RedirectResponse(url="/relay/v2/dashboard/login", status_code=307)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "version": __version__,
        "mode": "core",
        "event_subscribers": event_bus.subscriber_count(),
    }


@app.get("/ready")
async def ready():
    """Liveness for task processing — checks the subsystems."""
    from relay_server.core import metrics
    from relay_server.core.db import get_conn

    db_ok = False
    conn = None
    try:
        conn = get_conn()
        conn.execute(q("SELECT 1"))
        db_ok = True
    except Exception:  # noqa: BLE001
        db_ok = False
    finally:
        # T-093: close the connection on exceptions too.
        if conn is not None:
            conn.close()

    scheduler_age = metrics.maintenance_age_seconds()
    # F-20: a failed maintenance sweep degrades readiness too —
    # scheduler_ok requires BOTH a fresh loop AND a healthy last sweep.
    scheduler_ok = (scheduler_age is not None and scheduler_age < 30) and metrics.maintenance_last_ok()
    return {
        "status": "ready" if (db_ok and scheduler_ok) else "degraded",
        "database": "ok" if db_ok else "error",
        "scheduler": "ok" if scheduler_ok else "unknown" if scheduler_age is None else "stale",
        # T-092: event_bus is not a liveness indicator for task processing —
        # `subscriber_count() >= 0` is always true and therefore never yields "error".
        # The in-process event bus registers itself on startup; a
        # subscriber count says nothing about relay health. The check that
        # actually carries signal is `scheduler_ok` (maintenance loop age).
        "maintenance_age_seconds": scheduler_age,
        # F-20: outcome of the last maintenance sweep (additive field).
        "maintenance_last_ok": metrics.maintenance_last_ok(),
    }


@app.get("/metrics")
async def metrics_endpoint():
    """Prometheus exposure (open like /health, no secrets)."""
    from relay_server.core import metrics
    from fastapi.responses import PlainTextResponse

    return PlainTextResponse(
        metrics.render_prometheus(),
        media_type="text/plain; version=0.0.4",
        headers={"Cache-Control": "no-store"},
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description="IOWAP v2")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Server command (default)
    server_parser = subparsers.add_parser("server", help="Run the relay server")
    server_parser.add_argument("--host", default=settings.host)
    server_parser.add_argument("--port", type=int, default=settings.port)
    server_parser.add_argument(
        "--enable-master-seed",
        action="store_true",
        help="Keep master-seed login enabled even if human admin users exist (recovery mode)",
    )
    server_parser.add_argument(
        "--config", help="Path to config YAML (overrides default ~/.relay/config.yaml)"
    )

    # Admin command
    admin_parser = subparsers.add_parser("admin", help="Administration commands")
    admin_sub = admin_parser.add_subparsers(dest="admin_command", help="Admin subcommands")
    init_master_parser = admin_sub.add_parser("init-master", help="Initialize master admin seed")
    init_master_parser.add_argument("--config", help="Path to config YAML")

    args = parser.parse_args(argv)

    if args.command == "admin":
        _run_admin_command(args)
        return

    # Bare invocation = "server" with settings defaults (the intended
    # default; before this fallback, bare calls crashed with
    # AttributeError on args.host, systemd restart-looped).
    if args.command is None:
        host, port = settings.host, settings.port
    else:
        host, port = args.host, args.port

    # TLS (T-111): if a cert is configured, require the key and serve HTTPS.
    uvicorn_kwargs: dict = {
        "log_level": settings.log_level,
        "reload": settings.reload,
        "timeout_graceful_shutdown": 5,
    }
    if settings.tls_certfile:
        if not settings.tls_keyfile:
            parser.error(
                "tls_certfile is set but tls_keyfile is missing — both are "
                "required to enable TLS."
            )
        if not settings.tls_certfile.exists() or not settings.tls_keyfile.exists():
            parser.error(
                "TLS cert/key file not found: "
                f"{settings.tls_certfile} / {settings.tls_keyfile}"
            )
        uvicorn_kwargs["ssl_certfile"] = str(settings.tls_certfile)
        uvicorn_kwargs["ssl_keyfile"] = str(settings.tls_keyfile)

    uvicorn.run(
        "relay_server.main:app",
        host=host,
        port=port,
        **uvicorn_kwargs,
    )


def _run_admin_command(args):
    from relay_server.core.auth import init_master_seed
    from relay_server.core.db import init_db
    from relay_server.core.users import has_admin_user

    init_db()
    if args.admin_command == "init-master":
        secret = init_master_seed()
        if secret:
            print("Master admin seed created.")
            print("WARNING: Store this secret securely. It will not be shown again.")
            print(f"SECRET: {secret}")
            sys.exit(0)
        print("Master admin seed already exists.", file=sys.stderr)
        sys.exit(1)
    print("Unknown admin command", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
