"""Pydantic-Settings for IOWAP."""

from pathlib import Path
from typing import Literal, Optional

import yaml
from pydantic import field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Server configuration. Env vars with RELAY_ prefix set defaults."""

    # Server
    host: str = "0.0.0.0"
    port: int = 8788
    log_level: str = "info"
    reload: bool = False
    enable_mdns: bool = False
    mdns_hostname: str = "iowap"
    mdns_service_name: str = "IOWAP Relay Service"

    # TLS (T-111). Server-side TLS only (no mTLS — node identity is already
    # handled by runtime tokens). When tls_certfile is set, the relay serves
    # HTTPS; otherwise plain HTTP. Homelab default is HTTP (Tailscale covers
    # the transport); the Internet/Community-Relay mode sets these to the
    # server's cert/key (e.g. from Caddy or Let's Encrypt).
    tls_certfile: Optional[Path] = None
    tls_keyfile: Optional[Path] = None

    # Paths
    db_path: Path = Path.home() / ".relay" / "server.db"
    config_path: Optional[Path] = Path.home() / ".relay" / "config.yaml"
    artifacts_dir: Path = Path.home() / ".relay" / "artifacts"
    chunked_uploads_dir: Path = Path.home() / ".relay" / "chunked_uploads"
    static_dir: Optional[Path] = None

    # Database backend selection (pluggable abstraction).
    # ``sqlite`` is the default; ``postgres`` is fully implemented
    # (SQLAlchemy engine + migrations). DSNs are only consulted when
    # the matching ``db_type`` is active.
    db_type: Literal["sqlite", "postgres"] = "sqlite"
    pg_dsn: str = ""

    # Auth
    token_ttl_hours: int = 168
    registration_secret_ttl_hours: int = 168
    claim_ttl_seconds: int = 60
    heartbeat_interval_seconds: int = 10
    heartbeat_timeout_multiplier: int = 5

    # T-207: SSE keepalive — ``: ping`` comment every N seconds on every
    # event stream, so a silent cluster never goes fully silent on the wire.
    # Must stay well below the node-side SSE read timeout (T-186,
    # iowap-node: 60s read timeout = 3× this interval).
    sse_ping_interval_seconds: float = 20.0

    # Dashboard session cookie
    session_secret: Optional[str] = None
    # T-116: optional deterministic master admin seed (RELAY_MASTER_SEED).
    # When set and no master seed exists yet, init_master_seed() uses it as-is
    # instead of generating a random secret — lets Docker/NAS setups pin the
    # seed in .env rather than fishing it from container logs.
    master_seed: Optional[str] = None
    enable_master_seed_login: bool = False
    session_cookie_secure: bool = True

    # Storage limits
    max_upload_bytes: int = 100 * 1024 * 1024  # 100 MiB
    max_payload_bytes: int = 10 * 1024 * 1024   # 10 MiB — task payload limit
    max_chunk_size: int = 10 * 1024 * 1024  # 10 MiB — per-chunk limit for chunked uploads

    # T-164: file-transfer ladder (server config, read by node-cli).
    # Up to max_inline_bytes a file is transferred inline (base64) in the
    # task payload; up to max_artifact_bytes via the transient artifact store,
    # beyond that via the bridge (storage node). The node-cli picks the smallest
    # suitable mode the capability supports (upload_modes).
    max_inline_bytes: int = 5 * 1024 * 1024     # 5 MB — up to here inline (base64)
    max_artifact_bytes: int = 50 * 1024 * 1024  # 50 MB — up to here artifact, beyond that bridge
    # T-165: the artifact store is transient — all files older than artifact_ttl_days
    # are deleted by the watchdog. The store is a transfer buffer,
    # not an archive (the permanent copy lives on the storage node).
    artifact_ttl_days: float = 7.0

    @field_validator("max_inline_bytes", "max_artifact_bytes")
    @classmethod
    def _positive_bytes(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("must be > 0")
        return v

    @field_validator("max_artifact_bytes")
    @classmethod
    def _artifact_gt_inline(cls, v: int, info) -> int:
        inline = info.data.get("max_inline_bytes")
        if inline is not None and v <= inline:
            raise ValueError(
                f"max_artifact_bytes ({v}) must be > max_inline_bytes ({inline})"
            )
        return v

    @field_validator("max_inline_bytes")
    @classmethod
    def _inline_fits_payload(cls, v: int, info) -> int:
        # base64 overhead ×1.4 — inline must fit inside the task payload.
        payload = info.data.get("max_payload_bytes")
        if payload is not None and v * 1.4 >= payload:
            raise ValueError(
                f"max_inline_bytes ({v}) × 1.4 (base64-Overhead) muss < "
                f"max_payload_bytes ({payload}) sein"
            )
        return v

    @field_validator("artifact_ttl_days")
    @classmethod
    def _ttl_positive(cls, v: float) -> float:
        if v < 1:
            raise ValueError("artifact_ttl_days must be >= 1")
        return v

    # Scheduler
    default_timeout_seconds: int = 300
    max_retries: int = 2
    # T-154: Long-Run lease. A `longrun`-note switches the stage to
    # accepted and starts this TTL; every note (any kind) resets it.
    # When it expires the stage becomes orphaned. After orphaned_ttl_seconds
    # as orphaned, the stage fails (24h Failsafe).
    longrun_ttl_seconds: int = 2 * 3600  # 2h
    orphaned_ttl_seconds: int = 24 * 3600  # 24h
    node_offline_grace_seconds: int = 600  # 10 min offline → fail

    @field_validator("claim_ttl_seconds")
    @classmethod
    def _claim_ttl_range(cls, v: int) -> int:
        # T-181: dashboard-configurable, bounded so the watchdog interval
        # stays sane and a runaway claim can never hang forever.
        if not 60 <= v <= 300:
            raise ValueError("claim_ttl_seconds must be between 60 and 300")
        return v

    @field_validator("max_retries")
    @classmethod
    def _max_retries_range(cls, v: int) -> int:
        if not 0 <= v <= 10:
            raise ValueError("max_retries must be between 0 and 10")
        return v

    # T-081: auto-busy — number of consecutive heartbeats a node's load
    # must stay at or above its load_cap before the server transitions
    # it to "busy". The counter resets as soon as the load drops below
    # the cap, at which point the node reverts to "idle".
    auto_busy_consecutive_heartbeats: int = 3

    # Maintenance (T-050)
    maintenance_interval_seconds: int = 5
    artifact_cleanup_max_age_days: float = 7.0
    orphaned_stage_interval_seconds: int = 300
    db_vacuum_interval_seconds: int = 86400
    # T-125: how often ``temp_route_cleanup`` sweeps expired temp bridge
    # routes from ``node_routes``. Permanent heartbeat routes
    # (``expires_at IS NULL``) are never touched by the sweep.
    temp_route_cleanup_interval_seconds: int = 300
    # T-124: maximum TTL a node may request when registering a temporary
    # bridge route via ``POST /node-routes/register``. 24h keeps a long
    # upload/download channel alive without letting stale routes
    # accumulate indefinitely.
    temp_route_max_ttl_seconds: int = 86400
    # T-206: comma-separated escape hatch for route proxy targets that are
    # legitimately *not* the node's own endpoint origin (Docker-internal
    # names, co-located services), e.g.
    # ``RELAY_ROUTE_TARGET_ALLOW_HOSTS="storage-node,relay.local:8791"``.
    # Empty (default) means: a route target must be the node's own origin and
    # must never be loopback/link-local/metadata.
    route_target_allow_hosts: str = ""

    # Capabilities
    capabilities_config_path: Path = Path.home() / ".relay" / "capabilities.yaml"

    class Config:
        env_prefix = "RELAY_"
        env_file = ".env"
        # Ignore unknown env vars (e.g. POSTGRES_USER/POSTGRES_DB from the
        # docker .env) instead of failing validation. The relay only reads
        # RELAY_-prefixed vars; unrelated vars must not crash startup.
        extra = "ignore"


def _load_yaml_config(path: Optional[Path]) -> dict:
    """Load optional YAML config and return as plain dict."""
    if not path or not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _coerce_path(value):
    """Convert string values from YAML to Path where needed."""
    if value is None:
        return None
    if isinstance(value, str):
        return Path(value).expanduser()
    return value


def _apply_yaml_overrides(base: Settings, path: Optional[Path]) -> Settings:
    """YAML config overrides env-var defaults."""
    yaml_data = _load_yaml_config(path)
    if not yaml_data:
        return base

    # Coerce path-like fields.
    for key in [
        "db_path",
        "config_path",
        "artifacts_dir",
        "chunked_uploads_dir",
        "static_dir",
        "capabilities_config_path",
        "tls_certfile",
        "tls_keyfile",
    ]:
        if key in yaml_data:
            yaml_data[key] = _coerce_path(yaml_data[key])

    merged = {**base.model_dump(), **yaml_data}
    return Settings(**merged)


# Env vars provide defaults; ~/.relay/config.yaml overrides them.
settings = _apply_yaml_overrides(Settings(), Settings().config_path)
