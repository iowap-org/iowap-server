"""Central maintenance scheduler (T-050).

Consolidates all periodic watchdog/cleanup tasks of the server into a
single :class:`MaintenanceScheduler`. Instead of maintaining multiple
independent ``asyncio`` tasks with their own sleep timers in ``main.py``,
there is a single loop that calls :meth:`MaintenanceScheduler.run_due` every
``settings.maintenance_interval_seconds`` seconds. Each registered
task only runs once its individual interval has elapsed.

Registered tasks (default intervals: see :meth:`register_defaults`):

* ``heartbeat_watchdog``        — :func:`relay_server.core.discovery.mark_offline_nodes`
* ``claim_ttl_watchdog``        — :meth:`relay_server.core.scheduler.Scheduler.release_or_fail_claims`
* ``token_cleanup``             — purge expired ``node_tokens`` rows
* ``artifact_cleanup``          — :func:`relay_server.core.artifacts.cleanup_orphaned_artifacts` (T-049)
* ``chunked_upload_cleanup``    — :meth:`ChunkedUploadManager.prune_stale`
* ``orphaned_stage_cleanup``    — :meth:`relay_server.core.scheduler.Scheduler.fail_orphaned_stages` (T-063)
* ``db_vacuum``                 — WAL checkpoint + ``VACUUM`` (1x daily)
* ``temp_route_cleanup``        — reap expired temp bridge routes (T-125)
"""

from __future__ import annotations

import logging
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List

import sqlalchemy as sa

from relay_server.config import settings
from relay_server.core.db import _is_sqlite, get_conn, q

logger = logging.getLogger("relay.maintenance")


# ---------------------------------------------------------------------------
# Token cleanup (inline — small enough, no separate module needed)
# ---------------------------------------------------------------------------


def _purge_expired_tokens() -> Dict[str, Any]:
    """Delete expired rows from ``node_tokens``. Returns ``{"deleted": n}``."""
    now = datetime.now(timezone.utc).isoformat()
    conn = get_conn()
    try:
        deleted = conn.execute(
            q("DELETE FROM node_tokens WHERE expires_at < ?", (now,))
        ).rowcount
        conn.commit()
        return {"deleted": deleted}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# DB vacuum (WAL checkpoint + VACUUM)
# ---------------------------------------------------------------------------


def _db_vacuum() -> Dict[str, Any]:
    """Reclaim disk space — backend-aware.

    On SQLite this runs a WAL checkpoint (``PRAGMA wal_checkpoint(TRUNCATE)``)
    followed by ``VACUUM``. On PostgreSQL the built-in ``autovacuum`` daemon
    handles bloat reclamation, so there is nothing to do here; we log a hint
    and return. Errors are logged but never raised — VACUUM can legitimately
    fail when another connection holds a write lock; the next run retries.

    Returns ``{"checkpointed": bool, "vacuumed": bool}``.
    """
    conn = get_conn()
    try:
        if not _is_sqlite(conn):
            # PostgreSQL (and other non-SQLite backends) manage their own
            # storage via autovacuum / ANALYZE; running a manual VACUUM from
            # the app is neither needed nor a single SQL statement there.
            logger.info(
                "db_vacuum: backend is not SQLite — skipping (PostgreSQL "
                "autovacuum manages bloat reclamation)"
            )
            return {"checkpointed": False, "vacuumed": False}

        checkpointed = False
        vacuumed = False
        try:
            conn.execute(q("PRAGMA wal_checkpoint(TRUNCATE)"))
            checkpointed = True
        except (sqlite3.OperationalError, sa.exc.OperationalError) as exc:
            logger.warning("WAL checkpoint failed: %s", exc)
        try:
            conn.execute(q("VACUUM"))
            vacuumed = True
        except (sqlite3.OperationalError, sa.exc.OperationalError) as exc:
            logger.warning("VACUUM failed: %s", exc)
        conn.commit()
        return {"checkpointed": checkpointed, "vacuumed": vacuumed}
    finally:
        conn.close()


def _temp_route_cleanup() -> Dict[str, Any]:
    """Reap expired temporary bridge routes (T-125).

    A temp route carries an ``expires_at`` ISO-8601 timestamp and a
    non-null ``channel_id``. Permanent heartbeat routes have
    ``expires_at IS NULL`` and are never touched here. We delete every
    row whose ``expires_at`` is in the past so a dead upload/download
    channel is cleaned up shortly after its TTL lapses (the proxy also
    treats expired rows as 404 on lookup via :func:`_expired`).
    """
    now = datetime.now(timezone.utc).isoformat()
    conn = get_conn()
    try:
        deleted = conn.execute(
            q(
                "DELETE FROM node_routes "
                "WHERE expires_at IS NOT NULL AND channel_id IS NOT NULL "
                "AND expires_at < ?",
                (now,),
            )
        ).rowcount
        conn.commit()
        return {"deleted": deleted}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# MaintenanceScheduler
# ---------------------------------------------------------------------------


class MaintenanceScheduler:
    """Registry + dispatcher for periodic maintenance tasks.

    Singleton character is ensured by the caller (``main.py``),
    which creates one instance per process. The class itself is stateless
    with respect to the outside world — all registered functions are pure
    DB operations.
    """

    def __init__(self) -> None:
        # name -> {"func", "interval", "last_run"}
        self._tasks: Dict[str, Dict[str, Any]] = {}

    # -- registration --------------------------------------------------

    def register(
        self, name: str, func: Callable[[], Dict[str, Any]], interval_seconds: int
    ) -> None:
        """Register or replace a maintenance task.

        ``func`` must be a zero-arg callable returning a dict
        (empty dict = nothing to do / no-op). A task that already exists
        under the same name is overwritten and its ``last_run`` is reset
        to 0 so it runs immediately on the next ``run_due``.
        """
        self._tasks[name] = {
            "func": func,
            "interval": int(interval_seconds),
            "last_run": 0.0,
        }

    def unregister(self, name: str) -> None:
        """Removes a registered task (no-op if absent)."""
        self._tasks.pop(name, None)

    def refresh_claim_ttl_watchdog(self) -> None:
        """T-181: re-register claim_ttl_watchdog with the current TTL.

        Called after settings overrides are applied so a claim_ttl_seconds
        change takes effect without a restart. ``register()`` overwrites
        the existing task and resets ``last_run`` to 0, so the next loop
        tick runs immediately (harmless — the watchdog query is idempotent).
        """
        from relay_server.core.scheduler import Scheduler  # lazy, wie register_defaults

        self.register(
            "claim_ttl_watchdog",
            Scheduler.release_or_fail_claims,
            settings.claim_ttl_seconds,
        )

    # -- execution -----------------------------------------------------

    def run_due(self) -> Dict[str, Dict[str, Any]]:
        """Runs all tasks whose interval has elapsed.

        Returns ``{name: result}`` only for tasks that actually ran
        (i.e. were due). A failure in one task does not affect the
        execution of the others — it is logged and recorded in the result
        as ``{"error": str(exc)}``.
        """
        now = time.monotonic()
        results: Dict[str, Dict[str, Any]] = {}
        for name, entry in list(self._tasks.items()):
            if now - entry["last_run"] < entry["interval"]:
                continue
            try:
                result = entry["func"]() or {}
            except Exception as exc:  # noqa: BLE001 — maintenance darf nie raise
                logger.exception("Maintenance task '%s' failed: %s", name, exc)
                result = {"error": str(exc)}
            entry["last_run"] = now
            results[name] = result
        return results

    def run_all(self) -> Dict[str, Dict[str, Any]]:
        """Runs **all** registered tasks immediately (ignores intervals).

        Used during graceful shutdown to perform one final cleanup pass.
        The ``last_run`` time is updated meanwhile.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for name, entry in list(self._tasks.items()):
            try:
                result = entry["func"]() or {}
            except Exception as exc:  # noqa: BLE001
                logger.exception("Maintenance task '%s' failed: %s", name, exc)
                result = {"error": str(exc)}
            entry["last_run"] = time.monotonic()
            results[name] = result
        return results

    # -- introspection -------------------------------------------------

    def status(self) -> List[Dict[str, Any]]:
        """Returns a sorted status list of all registered tasks.

        Each entry: ``{name, interval, last_run, next_run}``.
        ``last_run``/``next_run`` are ``time.monotonic()`` seconds
        (relative to the process) — suitable for diagnostics/logging, not
        for persistence.
        """
        now = time.monotonic()
        out: List[Dict[str, Any]] = []
        for name, entry in sorted(self._tasks.items()):
            last = float(entry["last_run"])
            interval = int(entry["interval"])
            next_run = last + interval if last else 0.0
            out.append(
                {
                    "name": name,
                    "interval": interval,
                    "last_run": last,
                    "next_run": next_run,
                    "due": (last == 0.0) or (now - last >= interval),
                }
            )
        return out

    # -- default registry ----------------------------------------------

    def register_defaults(self) -> None:
        """Registers the server's default task set.

        Intervals are read from :mod:`relay_server.config.settings`,
        so they can be overridden via YAML/env. Imports are deliberately
        lazy (inline) so that ``maintenance`` can be imported before
        ``init_db`` has run — and so tests can selectively replace
        individual tasks with mocks.
        """
        from relay_server.core.artifacts import cleanup_expired_artifacts
        from relay_server.core.chunked_upload import chunked_manager
        from relay_server.core.discovery import mark_offline_nodes
        from relay_server.core.scheduler import Scheduler

        # Heartbeat / offline watchdog — kurzes Intervall, da direkt vom
        # heartbeat_timeout_multiplier abgeleitet.
        self.register(
            "heartbeat_watchdog",
            lambda: {"offline": mark_offline_nodes()},
            settings.heartbeat_interval_seconds,
        )

        # Claim-TTL watchdog — longer interval than the heartbeat, since claims
        # have a one-minute TTL.
        self.register(
            "claim_ttl_watchdog",
            Scheduler.release_or_fail_claims,
            settings.claim_ttl_seconds,
        )

        # Token cleanup — once per hour.
        self.register("token_cleanup", _purge_expired_tokens, 3600)

        # Artifact cleanup (T-049/T-165) — once per hour. T-165 deletes
        # all artifacts older than artifact_ttl_days (transient store),
        # not just orphaned ones. The permanent copy lives on the storage node.
        self.register(
            "artifact_cleanup",
            lambda: cleanup_expired_artifacts(
                max_age_days=settings.artifact_ttl_days
            ),
            3600,
        )

        # Chunked-upload session cleanup — once per hour.
        self.register(
            "chunked_upload_cleanup",
            lambda: {"pruned": chunked_manager.prune_stale()},
            3600,
        )

        # Orphaned-stage watchdog (T-063) — mittleres Intervall.
        self.register(
            "orphaned_stage_cleanup",
            Scheduler.fail_orphaned_stages,
            settings.orphaned_stage_interval_seconds,
        )

        # T-154: Long-Run lease watchdog — accepted→orphaned after 2h without a note,
        # orphaned→failed nach 24h, Node offline 10min → failed.
        self.register(
            "longrun_lease_cleanup",
            Scheduler.enforce_longrun_leases,
            settings.orphaned_stage_interval_seconds,
        )

        # DB VACUUM — once per day.
        self.register("db_vacuum", _db_vacuum, settings.db_vacuum_interval_seconds)

        # T-125: temp bridge route cleanup — reaps expired rows in
        # ``node_routes`` (expires_at < now AND channel_id IS NOT NULL).
        # Permanent heartbeat routes (expires_at IS NULL) are left alone.
        self.register(
            "temp_route_cleanup",
            _temp_route_cleanup,
            settings.temp_route_cleanup_interval_seconds,
        )


# T-181: module-level singleton — main.py drives the loop with it,
# core/db.apply_settings_overrides() re-registers watchdogs on it after
# dashboard edits. (Pattern: core/chunked_upload.py chunked_manager)
maintenance_scheduler = MaintenanceScheduler()
