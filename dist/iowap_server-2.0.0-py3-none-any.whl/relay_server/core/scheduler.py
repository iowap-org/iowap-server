"""Scheduler core logic — DAG staging, capability matching, claim/complete."""

import functools
import json
import secrets
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import sqlalchemy as sa

from relay_server.config import settings
from relay_server.core.artifacts import delete_artifact, list_artifacts, store_artifact
from relay_server.core.db import get_capability_details, get_conn, get_node_capability_names, q
from relay_server.core.events import event_bus
from relay_server.core.status import (
    StatusCategory,
    node_can_claim,
    node_live_statuses,
    node_statuses_in_category,
    stage_statuses_in_category,
    task_statuses_in_category,
)

# ---------------------------------------------------------------------------
# Retry helper for SQLite lock contention
# ---------------------------------------------------------------------------

_LOCKED_RETRIES = 5
_LOCKED_BASE_DELAY = 0.05


def _retry_db_write(func):
    """Retry a DB write on ``database is locked`` with exponential backoff."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        last_error = None
        delay = _LOCKED_BASE_DELAY
        for attempt in range(_LOCKED_RETRIES):
            try:
                return func(*args, **kwargs)
            except (sqlite3.OperationalError, sa.exc.OperationalError) as exc:
                if "database is locked" not in str(exc) and "locked" not in str(exc):
                    raise
                last_error = exc
                if attempt < _LOCKED_RETRIES - 1:
                    time.sleep(delay)
                    delay *= 2
        raise last_error  # type: ignore[misc]

    return wrapper


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _format_time(dt: datetime) -> str:
    return dt.isoformat()


def _generate_id(prefix: str = "id") -> str:
    return f"{prefix}_{secrets.token_urlsafe(12)}"


def _serialize(value: Any) -> Optional[str]:
    return json.dumps(value) if value is not None else None


def _parse(value: Optional[str]) -> Optional[Any]:
    if not value:
        return None
    try:
        return json.loads(value)
    except Exception:
        return None


class Scheduler:
    """Task scheduler with DAG stages."""

    @staticmethod
    @_retry_db_write
    def create_task(
        task_name: str,
        stages: List[Dict[str, Any]],
        priority: int = 0,
        owner_node_id: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        idempotency_key: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new task and decompose it into stages.

        T-045: When ``idempotency_key`` is given and a task with the same
        key already exists, that existing task is returned unchanged
        (duplicate suppression on client retries).
        """
        # Idempotency check: same key → return existing task.
        if idempotency_key:
            conn = get_conn()
            try:
                row = conn.execute(
                    q("SELECT task_id FROM tasks WHERE idempotency_key = ?", (idempotency_key,))
                ).fetchone()
            finally:
                conn.close()
            if row:
                return {"task_id": row["task_id"]}

        task_id = _generate_id("task")
        now = _format_time(_now())
        default_timeout = timeout_seconds or settings.default_timeout_seconds

        conn = get_conn()
        try:
            try:
                conn.execute(
                q("""
                INSERT INTO tasks (task_id, task_name, status, priority, owner_node_id,
                                   submitted_by, timeout_seconds, idempotency_key, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (task_id, task_name, "pending", priority, owner_node_id, submitted_by, default_timeout, idempotency_key, now, now)),
                )
            except sqlite3.IntegrityError:
                # Lost a race against a concurrent submit with the same key —
                # return the winner's task instead of failing.
                if idempotency_key:
                    row = conn.execute(
                        q("SELECT task_id FROM tasks WHERE idempotency_key = ?", (idempotency_key,))
                    ).fetchone()
                    if row:
                        return {"task_id": row["task_id"]}
                raise

            # Build stage records.
            stage_records = []
            for idx, stage in enumerate(stages):
                stage_id = _generate_id("stage")
                deps = stage.get("depends_on")
                stage_records.append(
                    {
                        "stage_id": stage_id,
                        "stage_name": stage["stage_name"],
                        "capability": stage["capability"],
                        "depends_on": _serialize(deps),
                        "status": "pending",
                        "sequence": idx,
                        "timeout_seconds": stage.get("timeout_seconds", default_timeout),
                        "payload": _serialize(stage.get("payload")),
                    }
                )

            # Linear DAG for MVP: first stage has no deps, each subsequent depends on previous.
            for idx, rec in enumerate(stage_records):
                if rec["depends_on"] is None and idx > 0:
                    rec["depends_on"] = _serialize([stage_records[idx - 1]["stage_id"]])

            for rec in stage_records:
                conn.execute(
                    q("""
                    INSERT INTO task_stages
                    (stage_id, task_id, stage_name, capability, depends_on, status,
                     sequence, timeout_seconds, payload, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        rec["stage_id"],
                        task_id,
                        rec["stage_name"],
                        rec["capability"],
                        rec["depends_on"],
                        rec["status"],
                        rec["sequence"],
                        rec["timeout_seconds"],
                        rec["payload"],
                        now,
                        now,
                    )),
                )

            conn.commit()
            event_bus.publish_sync("task_created", {"task_id": task_id, "task_name": task_name})
            event_bus.publish_sync(
                "status_changed",
                {
                    "entity_type": "task",
                    "entity_id": task_id,
                    "old_status": None,
                    "new_status": "pending",
                },
            )
            return {"task_id": task_id, "status": "pending", "stage_count": len(stage_records)}
        finally:
            conn.close()

    @staticmethod
    def list_tasks(
        status: Optional[str] = None,
        owner_node_id: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        conn = get_conn()
        try:
            # T-005g + T-227 scoping: with ``owner_node_id`` set (non-admin
            # caller), a node sees its own tasks, the tasks it submitted
            # (sender view) and ownerless tasks — the scheduler routes
            # ownerless sub-tasks to any capable node until the first
            # claim flips the owner (T-227). ``owner_node_id=None`` is the
            # admin view (unscoped).
            where: List[str] = []
            args: List[Any] = []
            if status:
                where.append("status = ?")
                args.append(status)
            if owner_node_id is not None:
                clause = "(owner_node_id IS NULL OR owner_node_id = ?"
                cargs: List[Any] = [owner_node_id]
                if submitted_by is not None:
                    clause += " OR submitted_by = ?"
                    cargs.append(submitted_by)
                clause += ")"
                where.append(clause)
                args.extend(cargs)
            sql = "SELECT * FROM tasks"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY priority DESC, created_at ASC"
            rows = conn.execute(q(sql, tuple(args))).fetchall()
            return [_task_row_to_dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_task(
        task_id: str,
        owner_node_id: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        conn = get_conn()
        try:
            # T-005g + T-227: tasks owned by ANOTHER node are invisible
            # (404 upstream) — unless the caller submitted the task (sender
            # view). NULL-owner tasks remain readable — nodes must poll
            # sub-task results for fan-out aggregation.
            row = conn.execute(q("SELECT * FROM tasks WHERE task_id = ?", (task_id,))).fetchone()
            if not row:
                return None
            if owner_node_id is not None:
                task_owner = row["owner_node_id"]
                task_sender = row["submitted_by"]
                if task_owner is not None and task_owner != owner_node_id and task_sender != owner_node_id:
                    return None
            task = _task_row_to_dict(row)
            stage_rows = conn.execute(
                q("SELECT * FROM task_stages WHERE task_id = ? ORDER BY sequence ASC", (task_id,)),
            ).fetchall()
            task["stages"] = []
            for r in stage_rows:
                stage = _stage_row_to_dict(r)
                # T-053: resolve capability_details for this stage. We
                # prefer the claiming node's row (if claimed) so the
                # description/schema matches the node actually working
                # on it; otherwise fall back to any node advertising
                # the capability.
                claimed_by = r["claimed_by"] if r["claimed_by"] else None
                cap_details = get_capability_details(r["capability"], node_id=claimed_by)
                if cap_details is not None:
                    stage["capability_details"] = cap_details
                task["stages"].append(stage)

            artifact_rows = conn.execute(
                q("SELECT artifact_id, name, mime_type, size_bytes, checksum, created_by FROM artifacts WHERE task_id = ?", (task_id,)),
            ).fetchall()
            task["artifacts"] = [
                {
                    "artifact_id": r["artifact_id"],
                    "name": r["name"],
                    "mime_type": r["mime_type"],
                    "size_bytes": r["size_bytes"],
                    # T-005g: checksum instead of storage_path (internal).
                    "checksum": r["checksum"],
                    "created_by": r["created_by"],
                }
                for r in artifact_rows
            ]

            # T-052: load notes attached to the task (mini-chat).
            note_rows = conn.execute(
                q("SELECT id, node_id, message, kind, created_at FROM task_notes "
                "WHERE task_id = ? ORDER BY created_at ASC", (task_id,)),
            ).fetchall()
            task["notes"] = [
                {
                    "id": r["id"],
                    "node_id": r["node_id"],
                    "message": r["message"],
                    "kind": r["kind"] or "info",
                    "created_at": r["created_at"],
                }
                for r in note_rows
            ]
            return task
        finally:
            conn.close()

    @staticmethod
    @_retry_db_write
    def claim_stage(
        node_id: str,
        capability: Optional[str] = None,
        capability_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Claim the next runnable stage for a node.

        If ``capability_type`` is given, only stages whose capability
        matches a capability of that type on this node are considered.
        """
        conn = get_conn()
        try:
            # T-080: status gate via the central registry. A node may
            # claim stages only when its status is AVAILABLE (approved,
            # online, idle). BUSY / OFFLINE / TERMINAL nodes cannot claim.
            # T-189 F-04: the gate is unconditional — it also applies to
            # explicit-capability claims, so a busy node gets None from
            # the core regardless of the requested capability. The node
            # row feeds the capability fallbacks below.
            node_row = conn.execute(
                q("SELECT capabilities, status FROM nodes WHERE node_id = ?", (node_id,)),
            ).fetchone()
            if not node_row or not node_can_claim(node_row["status"]):
                return None

            # Determine capabilities of the node if not provided.
            if not capability:
                # Use the normalized index for capability names. Fall back
                # to the JSON column if the index is empty (e.g. legacy
                # node that has not heartbeat-synced yet).
                cap_names = get_node_capability_names(node_id)
                if not cap_names:
                    caps = _parse(node_row["capabilities"]) or []
                    if capability_type:
                        caps = [
                            c for c in caps
                            if isinstance(c, dict)
                            and str(c.get("type", "")).lower() == capability_type.lower()
                        ]
                    cap_names = [c["name"] for c in caps if isinstance(c, dict) and c.get("name")]
                    if not cap_names:
                        return None
                elif capability_type:
                    # Filter the normalized index by type via a direct
                    # query — avoids loading the full JSON payload.
                    rows = conn.execute(
                        q("SELECT capability_name FROM node_capabilities "
                        "WHERE node_id = ? AND LOWER(capability_type) = LOWER(?)", (node_id, capability_type)),
                    ).fetchall()
                    cap_names = [r["capability_name"] for r in rows]
                    if not cap_names:
                        return None
            else:
                # T-189 F-04: an explicitly requested capability must be
                # advertised by this node — validated against the
                # normalized node_capabilities index (T-026) with the
                # parsed JSON capabilities column as fallback, mirroring
                # the implicit branch. A capability the node does not
                # offer is a silent refusal (None), consistent with the
                # non-match behavior of the query below.
                cap_names = [capability]
                offered = get_node_capability_names(node_id)
                if not offered:
                    caps = _parse(node_row["capabilities"]) or []
                    offered = [c["name"] for c in caps if isinstance(c, dict) and c.get("name")]
                if capability not in offered:
                    return None

            # Find pending stages whose capability matches and dependencies are completed.
            # T-229: order candidates by task priority DESC, then creation
            # order (FIFO), then per-task stage sequence — tasks.priority was
            # display-only before; it now drives the claim order.
            # JOIN excludes orphan stages (no task row) and provides the
            # priority fields.
            rows = conn.execute(
                q(
                    "SELECT s.* FROM task_stages s "
                    "JOIN tasks t ON t.task_id = s.task_id "
                    "WHERE s.status = 'pending' AND s.capability IN ({}) ".format(
                        ",".join("?" for _ in cap_names)
                    )
                    + "ORDER BY t.priority DESC, t.created_at ASC, s.sequence ASC",
                    tuple(cap_names),
                )
            ).fetchall()

            now = _format_time(_now())
            claim_ttl = _format_time(
                _now() + __import__("datetime").timedelta(seconds=settings.claim_ttl_seconds)
            )

            for row in rows:
                deps = _parse(row["depends_on"]) or []
                if deps:
                    completed = conn.execute(
                        q(
                            "SELECT COUNT(*) FROM task_stages WHERE stage_id IN ({}) AND status = 'completed'".format(
                                ",".join("?" for _ in deps)
                            ),
                            deps,
                        )
                    ).fetchone()[0]
                    if completed != len(deps):
                        continue

                # If the task has an owner_node_id, only that node
                # may claim the stage. Other nodes skip it.
                # T-067: if the addressed node no longer exists
                # (deleted), the stage is marked failed instead of
                # staying pending forever.
                task_owner = conn.execute(
                    q("SELECT owner_node_id FROM tasks WHERE task_id = ?", (row["task_id"],)),
                ).fetchone()[0]
                if task_owner:
                    if task_owner != node_id:
                        # Check whether the addressed node still exists at all.
                        owner_exists = conn.execute(
                            q("SELECT 1 FROM nodes WHERE node_id = ?", (task_owner,))
                        ).fetchone()
                        if not owner_exists:
                            # Owner deleted → fail the stage.
                            conn.execute(
                                q("UPDATE task_stages SET status = 'failed', updated_at = ? "
                                "WHERE stage_id = ? AND status = 'pending'", (now, row["stage_id"])),
                            )
                            conn.commit()
                        continue

                # Claim this stage atomically.
                stage_id = row["stage_id"]
                result = conn.execute(
                    q("""
                    UPDATE task_stages
                    SET status = 'claimed', claimed_by = ?, claimed_at = ?, claim_expires_at = ?, updated_at = ?
                    WHERE stage_id = ? AND status = 'pending'
                    """, (node_id, now, claim_ttl, now, stage_id)),
                )
                # ``conn.total_changes`` is sqlite3-specific; SQLAlchemy's
                # ``CursorResult.rowcount`` is the portable equivalent and
                # reports how many rows the UPDATE actually matched.
                if result.rowcount == 0:
                    continue

                # T-227: the first claim of an ownerless single-stage task
                # makes the claimer its owner ("who received the order") —
                # the broad NULL-owner read ends here and visibility narrows
                # to owner + sender (submitted_by). Multi-stage fan-out
                # tasks never flip: mixed-capability stages must stay
                # claimable by any capable node.
                stage_total = conn.execute(
                    q("SELECT COUNT(*) FROM task_stages WHERE task_id = ?", (row["task_id"],)),
                ).fetchone()[0]
                if stage_total == 1:
                    conn.execute(
                        q(
                            "UPDATE tasks SET owner_node_id = ?, updated_at = ?"
                            " WHERE task_id = ? AND owner_node_id IS NULL",
                            (node_id, now, row["task_id"]),
                        ),
                    )

                # Update task status to running if first claim.
                task_before = conn.execute(
                    q("SELECT status FROM tasks WHERE task_id = ?", (row["task_id"],))
                ).fetchone()
                task_old_status = task_before["status"] if task_before else None
                conn.execute(
                    q("UPDATE tasks SET status = 'running', updated_at = ? WHERE task_id = ? AND status = 'pending'", (now, row["task_id"])),
                )
                task_new_status = "running" if task_old_status == "pending" else task_old_status
                conn.commit()

                event_bus.publish_sync(
                    "stage_claimed",
                    {"task_id": row["task_id"], "stage_id": stage_id, "node_id": node_id},
                )
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "stage",
                        "entity_id": stage_id,
                        "old_status": "pending",
                        "new_status": "claimed",
                    },
                )
                if task_old_status != task_new_status:
                    event_bus.publish_sync(
                        "status_changed",
                        {
                            "entity_type": "task",
                            "entity_id": row["task_id"],
                            "old_status": task_old_status,
                            "new_status": task_new_status,
                        },
                    )
                stage_dict = _stage_row_to_dict(
                    conn.execute(
                        q("SELECT * FROM task_stages WHERE stage_id = ?", (stage_id,))
                    ).fetchone()
                )
                # T-053: attach resolved capability_details so the
                # claiming node sees the description / input_schema of
                # the capability it just claimed, without a second
                # round-trip to the discovery API.
                cap_details = get_capability_details(row["capability"], node_id=node_id)
                if cap_details is not None:
                    stage_dict["capability_details"] = cap_details
                return stage_dict

            return None
        finally:
            conn.close()

    @staticmethod
    @_retry_db_write
    def add_note(task_id: str, node_id: str, message: str, kind: str = "info") -> Optional[Dict[str, Any]]:
        """Append a task note (T-052 mini-chat between nodes).

        T-154: ``kind`` drives the Long-Run lease. Every note updates the
        stage's ``last_note_at`` (note-based heartbeat). A ``kind=longrun``
        note additionally switches the stage from ``claimed`` to ``accepted``
        and starts a 2h TTL — the worker signals it will take longer than
        the claim TTL (claim_ttl_seconds, default 60s).

        Returns ``{"id", "task_id", "node_id", "message", "kind", "created_at"}``
        on success, or ``None`` when the task does not exist.
        """
        conn = get_conn()
        try:
            row = conn.execute(
                q("SELECT task_id FROM tasks WHERE task_id = ?", (task_id,))
            ).fetchone()
            if not row:
                return None
            now = _format_time(_now())
            cur = conn.execute(
                q("INSERT INTO task_notes (task_id, node_id, message, kind, created_at) "
                "VALUES (?, ?, ?, ?, ?)", (task_id, node_id, message, kind, now)),
            )
            note_id = cur.lastrowid

            # T-154: update the owning stage's note-based heartbeat TTL.
            # The task's stage is the one currently claimed by this node.
            ttl_expires = _format_time(_now() + timedelta(seconds=settings.longrun_ttl_seconds))
            conn.execute(
                q(
                    "UPDATE task_stages SET last_note_at = ?, longrun_ttl_expires_at = ? "
                    "WHERE task_id = ? AND claimed_by = ?",
                    (now, ttl_expires, task_id, node_id),
                ),
            )

            # kind=longrun: switch the claimed stage to accepted (worker took
            # over, not re-claimable) so the claim-TTL watchdog does not
            # release it back to pending (T-181: there is no stage/task
            # timeout enforcement — the claim TTL is the only claim timer).
            if kind == "longrun":
                # registry-legal since T-189 F-08 (claimed→accepted)
                conn.execute(
                    q(
                        "UPDATE task_stages SET status = 'accepted', updated_at = ? "
                        "WHERE task_id = ? AND claimed_by = ? AND status = 'claimed'",
                        (now, task_id, node_id),
                    ),
                )

            # T-154: any note from the worker on an orphaned stage signals
            # the worker is alive again → back to accepted (2h lease restarts).
            # registry-legal since T-189 F-08 (orphaned→accepted)
            conn.execute(
                q(
                    "UPDATE task_stages SET status = 'accepted', updated_at = ? "
                    "WHERE task_id = ? AND claimed_by = ? AND status = 'orphaned'",
                    (now, task_id, node_id),
                ),
            )

            conn.commit()
            return {
                "id": note_id,
                "task_id": task_id,
                "node_id": node_id,
                "message": message,
                "kind": kind,
                "created_at": now,
            }
        finally:
            conn.close()

    @staticmethod
    def artifact_task_owner(
        task_id: str,
    ) -> Optional[str]:
        """Return a task's ``owner_node_id`` (``None`` when ownerless/missing).

        T-005g helper for artifact-endpoint ownership checks: artifact
        metadata, deletion, and upload must only be served for tasks the
        caller owns (or ownerless fan-out tasks). Admin callers skip the
        check entirely at the API layer.
        """
        conn = get_conn()
        try:
            row = conn.execute(
                q("SELECT owner_node_id FROM tasks WHERE task_id = ?", (task_id,))
            ).fetchone()
            if not row:
                return None
            return row["owner_node_id"]
        finally:
            conn.close()

    @staticmethod
    def artifact_task_sender(task_id: str) -> Optional[str]:
        """Return a task's ``submitted_by`` (T-227; None when unset/missing).

        Mirrors ``artifact_task_owner`` for the sender side of the T-227
        visibility predicate: artifact endpoints must serve the sender as
        well as the owner.
        """
        conn = get_conn()
        try:
            row = conn.execute(
                q("SELECT submitted_by FROM tasks WHERE task_id = ?", (task_id,))
            ).fetchone()
            if not row:
                return None
            return row["submitted_by"]
        finally:
            conn.close()

    @staticmethod
    def delete_artifact_scoped(
        artifact_id: str,
        owner_node_id: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> bool:
        """Delete an artifact with owner/sender scoping (T-005g + T-227).

        Resolution order mirrors ``get_task``: the artifact's task must be
        ownerless (NULL), owned by ``owner_node_id`` or submitted by
        ``submitted_by``; a foreign task's artifact is reported as
        ``False`` (→ 404 upstream) and left untouched. Admin callers
        pass ``owner_node_id=None`` and skip the scoping check.
        """
        conn = get_conn()
        try:
            art = conn.execute(
                q("SELECT task_id FROM artifacts WHERE artifact_id = ?", (artifact_id,))
            ).fetchone()
            if not art:
                return False
            task_owner: Optional[str] = None
            task_sender: Optional[str] = None
            if art["task_id"]:
                trow = conn.execute(
                    q("SELECT owner_node_id, submitted_by FROM tasks WHERE task_id = ?", (art["task_id"],))
                ).fetchone()
                if trow:
                    task_owner = trow["owner_node_id"]
                    task_sender = trow["submitted_by"]
            if (owner_node_id is not None and task_owner is not None
                    and task_owner != owner_node_id and task_sender != owner_node_id):
                return False
        finally:
            conn.close()
        return delete_artifact(artifact_id, owner_node_id=None)

    @staticmethod
    def list_artifacts_scoped(
        task_id: str,
        owner_node_id: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List a task's artifacts with owner/sender scoping (T-005g + T-227).

        When ``owner_node_id`` is given (non-admin caller), the task must
        be ownerless, owned by this node or submitted by the caller —
        otherwise the artifact list is reported as missing (empty result
        → 404 upstream), mirroring ``get_task``'s scoping semantics.
        """
        if owner_node_id is not None:
            task_owner = Scheduler.artifact_task_owner(task_id)
            task_sender = Scheduler.artifact_task_sender(task_id)
            # A missing task and a foreign-owned task both yield a scoped
            # empty result (404 upstream) — no existence oracle.
            if (
                task_owner is not None
                and task_owner != owner_node_id
                and task_sender != owner_node_id
            ):
                return []
        return list_artifacts(task_id=task_id)

    @staticmethod
    def upload_artifact_scoped(
        name: str,
        content: bytes,
        mime_type: Optional[str] = None,
        task_id: Optional[str] = None,
        stage_id: Optional[str] = None,
        created_by: Optional[str] = None,
        owner_node_id: Optional[str] = None,
        submitted_by: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Store an artifact attached to a task with owner/sender scoping.

        T-005g + T-227: non-admin callers (``owner_node_id`` set) may only
        attach artifacts to ownerless, own or sender tasks — a foreign
        task yields ``None`` (→ 404 upstream) and nothing is written to
        disk or DB. Admin callers pass ``owner_node_id=None`` and only
        get the plain existence check (task must exist).
        """
        if owner_node_id is not None and task_id:
            task_owner = Scheduler.artifact_task_owner(task_id)
            task_sender = Scheduler.artifact_task_sender(task_id)
            if (
                task_owner is not None
                and task_owner != owner_node_id
                and task_sender != owner_node_id
            ):
                return None
        return store_artifact(
            name=name,
            content=content,
            mime_type=mime_type,
            task_id=task_id,
            stage_id=stage_id,
            created_by=created_by,
        )

    @staticmethod
    @_retry_db_write
    def complete_stage(
        stage_id: str, node_id: str, result: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        """Mark a claimed stage as completed."""
        conn = get_conn()
        try:
            row = conn.execute(
                q("SELECT * FROM task_stages WHERE stage_id = ? AND claimed_by = ? AND status IN ('claimed', 'accepted', 'orphaned')", (stage_id, node_id)),
            ).fetchone()
            if not row:
                return None

            now = _format_time(_now())
            conn.execute(
                q("""
                UPDATE task_stages
                SET status = 'completed', completed_at = ?, result = ?, updated_at = ?
                WHERE stage_id = ?
                """, (now, _serialize(result), now, stage_id)),
            )

            # Check if all stages completed (T-189 F-03: "not done" = stage
            # status in the PENDING or BUSY category — accepted/orphaned
            # stages are still open work, terminal stages never count).
            non_terminal = stage_statuses_in_category(StatusCategory.PENDING) + stage_statuses_in_category(StatusCategory.BUSY)
            placeholders = ",".join("?" for _ in non_terminal)
            pending_count = conn.execute(
                q(f"SELECT COUNT(*) FROM task_stages WHERE task_id = ? AND status IN ({placeholders})", (row["task_id"], *non_terminal)),
            ).fetchone()[0]
            if pending_count == 0:
                # T-189: emit the task's real prior status instead of a
                # hardcoded "running" (Goal: never guess old_status).
                task_before = conn.execute(
                    q("SELECT status FROM tasks WHERE task_id = ?", (row["task_id"],)),
                ).fetchone()
                task_old_status = task_before["status"] if task_before else None
                conn.execute(
                    q("UPDATE tasks SET status = 'completed', completed_at = ?, updated_at = ? WHERE task_id = ?", (now, now, row["task_id"])),
                )
                event_bus.publish_sync(
                    "task_completed",
                    {"task_id": row["task_id"]},
                )
                if task_old_status != "completed":
                    event_bus.publish_sync(
                        "status_changed",
                        {
                            "entity_type": "task",
                            "entity_id": row["task_id"],
                            "old_status": task_old_status,
                            "new_status": "completed",
                        },
                    )
            conn.commit()

            event_bus.publish_sync(
                "stage_completed",
                {"task_id": row["task_id"], "stage_id": stage_id, "node_id": node_id},
            )
            event_bus.publish_sync(
                "status_changed",
                {
                    "entity_type": "stage",
                    "entity_id": stage_id,
                    "old_status": row["status"],
                    "new_status": "completed",
                },
            )
            return _stage_row_to_dict(
                conn.execute(q("SELECT * FROM task_stages WHERE stage_id = ?", (stage_id,))).fetchone()
            )
        finally:
            conn.close()

    @staticmethod
    @_retry_db_write
    def release_or_fail_claims() -> Dict[str, Any]:
        """Release or fail stages whose claim TTL expired (T-060).

        For each expired claim the stage's ``retry_count`` is
        incremented. When it exceeds ``settings.max_retries`` the stage
        is marked ``failed`` (and the task is failed too if all of its
        stages are failed) instead of being put back to ``pending``,
        which prevents the daemon from reclaiming the same stage forever
        and driving the server into RAM overflow.

        Returns a dict with the stage ids that were released back to
        ``pending`` (``released``), failed (``failed``) and the task ids
        that were failed as a consequence (``tasks_failed``).
        """
        now = _format_time(_now())
        conn = get_conn()
        try:
            rows = conn.execute(
                q("SELECT stage_id, task_id, retry_count FROM task_stages "
                "WHERE status = 'claimed' AND claim_expires_at < ?", (now,)),
            ).fetchall()
            if not rows:
                return {"released": [], "failed": [], "tasks_failed": []}

            released: List[str] = []
            failed_stage_ids: List[str] = []
            affected_tasks: set[str] = set()

            for row in rows:
                stage_id = row["stage_id"]
                task_id = row["task_id"]
                retry_count = int(row["retry_count"] or 0) + 1
                if retry_count > settings.max_retries:
                    # Retry budget exhausted → fail the stage permanently.
                    conn.execute(
                        q("""
                        UPDATE task_stages
                        SET status = 'failed', retry_count = ?, claimed_by = NULL,
                            claimed_at = NULL, claim_expires_at = NULL, updated_at = ?
                        WHERE stage_id = ?
                        """, (retry_count, now, stage_id)),
                    )
                    failed_stage_ids.append(stage_id)
                    affected_tasks.add(task_id)
                else:
                    # Still within the retry budget → put back to pending.
                    conn.execute(
                        q("""
                        UPDATE task_stages
                        SET status = 'pending', retry_count = ?, claimed_by = NULL,
                            claimed_at = NULL, claim_expires_at = NULL, updated_at = ?
                        WHERE stage_id = ?
                        """, (retry_count, now, stage_id)),
                    )
                    released.append(stage_id)

            tasks_failed = _fail_tasks_if_all_stages_done(
                conn, affected_tasks, now, terminal_stage_status=("failed",)
            )
            # T-189 F-05: linear failure policy — a single permanently
            # failed stage fails the task even while other stages are
            # still pending. The helper publishes its task_failed /
            # status_changed events itself (it knows the true old_status).
            linear_tasks_failed = _fail_tasks_with_failed_critical_stages(
                conn, affected_tasks, now
            )
            conn.commit()

            for stage_id in failed_stage_ids:
                event_bus.publish_sync("stage_failed", {"stage_id": stage_id})
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "stage",
                        "entity_id": stage_id,
                        "old_status": "claimed",
                        "new_status": "failed",
                    },
                )
            for stage_id in released:
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "stage",
                        "entity_id": stage_id,
                        "old_status": "claimed",
                        "new_status": "pending",
                    },
                )
            for task_id in tasks_failed:
                event_bus.publish_sync("task_failed", {"task_id": task_id})
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "task",
                        "entity_id": task_id,
                        "old_status": "running",
                        "new_status": "failed",
                    },
                )

            return {
                "released": released,
                "failed": failed_stage_ids,
                "tasks_failed": tasks_failed + linear_tasks_failed,
            }
        finally:
            conn.close()

    @staticmethod
    @_retry_db_write
    def fail_orphaned_stages() -> Dict[str, Any]:
        """Fail ``pending`` stages whose capability no node heartbeats (T-063).

        A stage is *orphaned* when its ``capability`` does not appear in
        :table:`node_capabilities` for any live (AVAILABLE or BUSY) node
        (T-189 F-06). Such a stage can never be claimed and would block
        the task forever; this watchdog marks it ``failed`` instead and
        fails the owning task too (T-189 F-05: a single permanently
        failed stage suffices — linear failure policy).

        Returns ``{"stages_failed": [...], "tasks_failed": [...]}``.
        """
        now = _format_time(_now())
        conn = get_conn()
        try:
            # Pending stages whose capability is not advertised by any
            # AVAILABLE or BUSY node (T-080: status gate via the central
            # registry). We intentionally do NOT filter on
            # ``node_capabilities.available``: that flag is only flipped
            # to 1 by an explicit worker-heartbeat, so a freshly approved
            # node (still on its first heartbeat) would otherwise be
            # treated as "not covering" the capability and its pending
            # stages would be failed spuriously. The authoritative
            # availability signal is the owning node's ``status``.
            # F-06: AVAILABLE+BUSY providers keep pending stages alive; claim-eligibility (node_can_claim) still applies at claim time.
            live_statuses = node_live_statuses()
            placeholders = ",".join("?" for _ in live_statuses) or "''"
            rows = conn.execute(
                q(f"""
                SELECT ts.stage_id, ts.task_id
                FROM task_stages ts
                WHERE ts.status = 'pending'
                  AND NOT EXISTS (
                      SELECT 1 FROM node_capabilities nc
                      JOIN nodes n ON n.node_id = nc.node_id
                      WHERE nc.capability_name = ts.capability
                        AND n.status IN ({placeholders})
                  )
                """, live_statuses),
            ).fetchall()
            if not rows:
                return {"stages_failed": [], "tasks_failed": []}

            failed_stage_ids: List[str] = []
            affected_tasks: set[str] = set()
            for row in rows:
                stage_id = row["stage_id"]
                task_id = row["task_id"]
                conn.execute(
                    q("""
                    UPDATE task_stages
                    SET status = 'failed', updated_at = ?
                    WHERE stage_id = ? AND status = 'pending'
                    """, (now, stage_id)),
                )
                failed_stage_ids.append(stage_id)
                affected_tasks.add(task_id)

            tasks_failed = _fail_tasks_if_all_stages_done(
                conn,
                affected_tasks,
                now,
                terminal_stage_status=("failed",),
            )
            # T-189 F-05: linear failure policy — a single permanently
            # failed stage fails the task even while other stages are
            # still pending. The helper publishes its task_failed /
            # status_changed events itself (it knows the true old_status).
            linear_tasks_failed = _fail_tasks_with_failed_critical_stages(
                conn, affected_tasks, now
            )
            conn.commit()

            for stage_id in failed_stage_ids:
                event_bus.publish_sync(
                    "stage_failed",
                    {"stage_id": stage_id, "reason": "orphaned_capability"},
                )
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "stage",
                        "entity_id": stage_id,
                        "old_status": "pending",
                        "new_status": "failed",
                    },
                )
            for task_id in tasks_failed:
                event_bus.publish_sync(
                    "task_failed",
                    {"task_id": task_id, "reason": "orphaned_stages"},
                )
                event_bus.publish_sync(
                    "status_changed",
                    {
                        "entity_type": "task",
                        "entity_id": task_id,
                        "old_status": "running",
                        "new_status": "failed",
                    },
                )

            return {
                "stages_failed": failed_stage_ids,
                "tasks_failed": tasks_failed + linear_tasks_failed,
            }
        finally:
            conn.close()

    @staticmethod
    @_retry_db_write
    def enforce_longrun_leases() -> Dict[str, Any]:
        """Enforce the T-154 Long-Run lease on accepted/orphaned stages.

        Rules:
        * ``accepted`` whose ``longrun_ttl_expires_at < now`` (2h without a
          note) → ``orphaned`` (not re-claimable, not failed).
        * ``orphaned`` whose ``last_note_at`` (or claim) is older than
          ``orphaned_ttl_seconds`` (24h) → ``failed``.
        * ``accepted``/``orphaned`` whose owning node has been offline
          longer than ``node_offline_grace_seconds`` (10 min) → ``failed``
          (a dead node's worker is presumed dead too).

        Returns ``{"accepted_orphaned": [...], "orphaned_failed": [...], "node_failed": [...], "tasks_failed": [...]}``.
        """
        now = _format_time(_now())
        conn = get_conn()
        try:
            accepted_orphaned: List[str] = []
            orphaned_failed: List[str] = []
            node_failed: List[str] = []
            affected_tasks: set[str] = set()

            # 1. accepted → orphaned when the 2h lease expired.
            overdue = conn.execute(
                q("""
                SELECT stage_id, task_id FROM task_stages
                WHERE status = 'accepted'
                  AND longrun_ttl_expires_at IS NOT NULL
                  AND longrun_ttl_expires_at < ?
                """, (now,)),
            ).fetchall()
            for r in overdue:
                conn.execute(
                    q("UPDATE task_stages SET status = 'orphaned', updated_at = ? WHERE stage_id = ?", (now, r["stage_id"])),
                )
                accepted_orphaned.append(r["stage_id"])
                affected_tasks.add(r["task_id"])
                event_bus.publish_sync("status_changed", {
                    "entity_type": "stage", "entity_id": r["stage_id"],
                    "old_status": "accepted", "new_status": "orphaned",
                })

            # 2. orphaned → failed when it has been orphaned > 24h.
            orphan_deadline = _format_time(_now() - timedelta(seconds=settings.orphaned_ttl_seconds))
            orphan_dead = conn.execute(
                q("""
                SELECT stage_id, task_id FROM task_stages
                WHERE status = 'orphaned'
                  AND (last_note_at IS NULL OR last_note_at < ?)
                """, (orphan_deadline,)),
            ).fetchall()
            for r in orphan_dead:
                conn.execute(
                    q("UPDATE task_stages SET status = 'failed', updated_at = ? WHERE stage_id = ?", (now, r["stage_id"])),
                )
                orphaned_failed.append(r["stage_id"])
                affected_tasks.add(r["task_id"])
                event_bus.publish_sync("status_changed", {
                    "entity_type": "stage", "entity_id": r["stage_id"],
                    "old_status": "orphaned", "new_status": "failed",
                })

            # 3. accepted/orphaned whose owner node is offline > grace → failed.
            #    A node is "live" when it is in the AVAILABLE or BUSY category
            #    (approved/online/idle/busy/maintenance). BUSY matters: T-081/T-113
            #    auto-transition a node to "busy" while it runs a heavy job (high
            #    load / queue_depth >= 1), and such a node is NOT offline — it is
            #    actively working. Using node_claim_statuses() (AVAILABLE only)
            #    here would wrongly fail accepted stages whose owner is busy.
            offline_deadline = _format_time(_now() - timedelta(seconds=settings.node_offline_grace_seconds))
            live_statuses = (
                node_statuses_in_category(StatusCategory.AVAILABLE)
                + node_statuses_in_category(StatusCategory.BUSY)
            )
            placeholders = ",".join("?" for _ in live_statuses) or "''"
            node_dead = conn.execute(
                q(f"""
                SELECT ts.stage_id, ts.task_id FROM task_stages ts
                WHERE ts.status IN ('accepted', 'orphaned')
                  AND ts.claimed_by IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1 FROM nodes n
                      WHERE n.node_id = ts.claimed_by
                        AND n.status IN ({placeholders})
                        AND (n.last_seen IS NULL OR n.last_seen >= ?)
                  )
                """, list(live_statuses) + [offline_deadline]),
            ).fetchall()
            for r in node_dead:
                conn.execute(
                    q("UPDATE task_stages SET status = 'failed', updated_at = ? WHERE stage_id = ?", (now, r["stage_id"])),
                )
                node_failed.append(r["stage_id"])
                affected_tasks.add(r["task_id"])
                event_bus.publish_sync("status_changed", {
                    "entity_type": "stage", "entity_id": r["stage_id"],
                    "old_status": "accepted_or_orphaned", "new_status": "failed",
                })

            tasks_failed = []
            if affected_tasks:
                tasks_failed = _fail_tasks_if_all_stages_done(
                    conn, affected_tasks, now, terminal_stage_status=("failed", "timed_out", "cancelled"),
                )
                for task_id in tasks_failed:
                    event_bus.publish_sync("task_failed", {"task_id": task_id, "reason": "longrun"})

            conn.commit()
            return {
                "accepted_orphaned": accepted_orphaned,
                "orphaned_failed": orphaned_failed,
                "node_failed": node_failed,
                "tasks_failed": tasks_failed,
            }
        finally:
            conn.close()


def _fail_tasks_if_all_stages_done(
    conn: sqlite3.Connection,
    task_ids: "set[str]",
    now: str,
    terminal_stage_status: tuple[str, ...],
) -> List[str]:
    """Mark tasks as ``failed`` when every stage is in a terminal state.

    Used by the retry / offline failure paths (T-060, T-061) to fail a
    task as soon as all of its stages have reached a terminal status.
    ``terminal_stage_status`` is the set of stage statuses that count
    as "done" for the purpose of this check (e.g. ``("failed",)`` or
    ``("completed", "failed", "timed_out")``).

    Returns the list of task ids that were transitioned to ``failed``.
    The caller is responsible for committing the transaction and
    publishing the ``task_failed`` events.
    """
    tasks_failed: List[str] = []
    for task_id in task_ids:
        placeholders = ",".join("?" for _ in terminal_stage_status)
        remaining = conn.execute(
            q(f"SELECT COUNT(*) FROM task_stages "
            f"WHERE task_id = ? AND status NOT IN ({placeholders})", (task_id, *terminal_stage_status)),
        ).fetchone()[0]
        if remaining == 0:
            conn.execute(
                q("UPDATE tasks SET status = 'failed', updated_at = ?, completed_at = ? "
                "WHERE task_id = ? AND status NOT IN ('failed', 'completed', 'timed_out')", (now, now, task_id)),
            )
            tasks_failed.append(task_id)
    return tasks_failed


def _fail_tasks_with_failed_critical_stages(
    conn: sqlite3.Connection,
    task_ids: "set[str]",
    now: str,
) -> list[str]:
    """Fail a task as soon as one of its stages failed permanently (T-189 F-05).

    Linear-Failure-Policy: a single exhausted (``failed``) stage fails the
    whole task, even while other stages are still pending. Downstream
    stages of the failed stage stay ``pending`` until the owner cancels
    or the task is deleted — no cascade cancel (board decision T-189).

    Only tasks still in a non-terminal state are transitioned; the
    caller is responsible for committing and publishing the
    ``task_failed`` / ``status_changed`` events.
    """
    terminal_tasks = task_statuses_in_category(StatusCategory.TERMINAL)
    tasks_failed: list[str] = []
    for task_id in task_ids:
        failed_count = conn.execute(
            q("SELECT COUNT(*) FROM task_stages WHERE task_id = ? AND status = 'failed'", (task_id,)),
        ).fetchone()[0]
        if failed_count == 0:
            continue
        task_row = conn.execute(
            q("SELECT status FROM tasks WHERE task_id = ?", (task_id,)),
        ).fetchone()
        if not task_row or task_row["status"] in terminal_tasks:
            continue
        old_status = task_row["status"]
        conn.execute(
            q("UPDATE tasks SET status = 'failed', updated_at = ?, completed_at = ? "
              "WHERE task_id = ? AND status NOT IN ('failed', 'completed', 'timed_out')", (now, now, task_id)),
        )
        tasks_failed.append(task_id)
        # Publish here with the true old_status read above — the frozen
        # return type (list of ids) gives the caller no way to know it.
        # The caller commits (established inline-publish pattern from
        # enforce_longrun_leases).
        event_bus.publish_sync("task_failed", {"task_id": task_id})
        event_bus.publish_sync(
            "status_changed",
            {
                "entity_type": "task",
                "entity_id": task_id,
                "old_status": old_status,
                "new_status": "failed",
            },
        )
    return tasks_failed


def fail_stages_of_deleted_node(
    conn: sqlite3.Connection,
    node_id: str,
    now: str,
) -> list[str]:
    """Fail stages claimed by a node that is about to be deleted (F-19).

    Marks every ``claimed`` stage of ``node_id`` as ``failed`` (F-19: never
    leave an ownerless ``claimed`` row behind), clears its claim fields and
    fails the owning tasks via the linear failure policy. The caller owns
    the transaction: this function issues UPDATEs on ``conn`` but does NOT
    commit; ``_fail_tasks_with_failed_critical_stages`` publishes the
    task-level ``task_failed``/``status_changed`` events inline (established
    pre-commit pattern, cf. enforce_longrun_leases).

    Returns the list of failed stage ids so the caller can publish
    ``stage_failed`` + stage ``status_changed`` events AFTER commit.
    """
    # D-12: claimed-only — pending stages have no owner to orphan and
    # terminal stages are already final. No cascade to other stages.
    rows = conn.execute(
        q(
            "SELECT stage_id, task_id FROM task_stages "
            "WHERE claimed_by = ? AND status = 'claimed'",
            (node_id,),
        ),
    ).fetchall()
    failed_stage_ids: list[str] = []
    affected_tasks: set[str] = set()
    for row in rows:
        stage_id = row["stage_id"]
        # fail_reason (D-3): no DB column exists — the failure reason
        # travels in the stage_failed event payload (reason='node_deleted')
        # published by the admin handler after commit.
        conn.execute(
            q(
                "UPDATE task_stages "
                "SET status = 'failed', updated_at = ?, claimed_by = NULL, "
                "claimed_at = NULL, claim_expires_at = NULL "
                "WHERE stage_id = ?",
                (now, stage_id),
            ),
        )
        failed_stage_ids.append(stage_id)
        affected_tasks.add(row["task_id"])
    if affected_tasks:
        # Linear failure policy (T-189 F-05): the helper publishes the
        # task-level events inline with the true old_status (D-2).
        _fail_tasks_with_failed_critical_stages(conn, affected_tasks, now)
    return failed_stage_ids


def _task_row_to_dict(row: Any) -> Dict[str, Any]:
    return {
        "task_id": row["task_id"],
        "task_name": row["task_name"],
        "status": row["status"],
        "priority": row["priority"],
        "owner_node_id": row["owner_node_id"],
        "timeout_seconds": row["timeout_seconds"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "completed_at": row["completed_at"],
    }


def _stage_row_to_dict(row: Any) -> Dict[str, Any]:
    return {
        "stage_id": row["stage_id"],
        "task_id": row["task_id"],
        "stage_name": row["stage_name"],
        "capability": row["capability"],
        "depends_on": _parse(row["depends_on"]),
        "status": row["status"],
        "sequence": row["sequence"],
        "timeout_seconds": row["timeout_seconds"],
        "payload": _parse(row["payload"]),
        "claimed_by": row["claimed_by"],
        "claimed_at": row["claimed_at"],
        "claim_expires_at": row["claim_expires_at"],
        "completed_at": row["completed_at"],
        "result": _parse(row["result"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "retry_count": int(row["retry_count"] or 0),
    }
