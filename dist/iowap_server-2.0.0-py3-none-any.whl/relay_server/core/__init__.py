"""Core service implementations."""
